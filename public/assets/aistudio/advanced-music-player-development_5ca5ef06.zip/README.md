# Sonora

Sonora is a local-first music player preview built with React, Web Audio, and Capacitor. It includes file/folder import, synced lyric editing, tap-to-sync and timestamp shifting, a waveform and live FFT spectrogram, a three-band EQ, safe gain boost, normalization, output profiles, A-B loop, speed and pitch preservation, sleep timer, shuffle, repeat, and six themes.

## Preview in a browser

```bash
npm ci
npm run dev
```

Open the local URL printed by Vite. A short public-domain ambient audio sample is bundled so the player can be tried without importing files. The sample comes from [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Hypnotic_ambient_electronic_music_by_MusicLM.mp3).

## Build the Android APK using GitHub

1. Push this repository to GitHub on the `main` branch, or start **Build Android APK** from the repository's **Actions** tab using **Run workflow**.
2. Wait for the workflow to finish, open the completed run, and download the `sonora-debug-apk` artifact.
3. Extract `app-debug.apk` and install it on an Android device, allowing installation from that source if prompted.

This is a debug-signed, installable testing APK, not a Play Store release. To build locally, install JDK 21 and Android SDK 35, then run `npm run build`, `npx cap sync android`, and `cd android && bash ./gradlew assembleDebug`.

## Current platform boundaries

- Browser-selected files exist only for the current session. Reopen the files or folder after restarting; lyrics, settings, and saved EQ profiles persist in browser storage.
- Folder selection depends on the browser or Android WebView file picker. If folder selection is unavailable on a device, use **Add audio files** to select multiple tracks.
- Audio format decoding and output-device selection depend on platform support. The spectrogram is a live scrolling FFT display, not an offline full-track scan or automatic hidden-image detector.
- A debug APK does not yet include native background playback, lock-screen audio integration beyond Media Session support, home-screen widgets, guaranteed gapless playback, ReplayGain metadata reading, or isolated vocal/instrument stems. Those require additional Android-native work or audio analysis and should not be assumed from the web preview.
