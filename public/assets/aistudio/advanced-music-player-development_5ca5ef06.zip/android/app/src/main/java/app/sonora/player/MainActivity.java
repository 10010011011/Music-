package app.sonora.player;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
