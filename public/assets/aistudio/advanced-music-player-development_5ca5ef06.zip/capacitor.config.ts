import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.sonora.player',
  appName: 'Sonora',
  webDir: 'dist',
};

export default config;