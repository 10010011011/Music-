import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, library, player, fmt } from "../lib/store";
import { ingest, openFolderHandle, savedFolder, playTrackIndex } from "../lib/library";
import { loadDemo } from "../lib/demo";
import { Icon, Btn, Cover } from "./ui";

const ROW = 60;

export function Pickers({ big = false }: { big?: boolean }) {
  const dirRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [saved, setSaved] = useState<FileSystemDirectoryHandle | undefined>();
  useEffect(() => { savedFolder().then(setSaved); }, []);
  const fromInput = (fl: FileList | null) => {
    if (!fl?.length) return;
    const arr = [...fl].map((f) => ({ file: f, path: (f as any).webkitRelativePath || f.name }));
    const root = arr[0].path.includes("/") ? arr[0].path.split("/")[0] : "Files";
    ingest(arr, root);
  };
  const openFolder = () => (window.showDirectoryPicker ? openFolderHandle() : dirRef.current?.click());
  return (
    <div className={`flex flex-wrap gap-2 ${big ? "justify-center" : ""}`}>
      <input ref={dirRef} type="file" className="hidden" multiple {...({ webkitdirectory: "", directory: "" } as any)} onChange={(e) => fromInput(e.target.files)} />
      <input ref={fileRef} type="file" className="hidden" multiple accept="audio/*,.lrc,.srt,.vtt,.flac,.opus,.m4a" onChange={(e) => fromInput(e.target.files)} />
      <Btn primary onClick={openFolder}><Icon n="folder" s={16} />Open folder</Btn>
      <Btn onClick={() => fileRef.current?.click()}><Icon n="plus" s={16} />Add files</Btn>
      {saved && <Btn onClick={() => openFolderHandle(saved)} title={saved.name}><Icon n="loop" s={16} />Reopen “{saved.name}”</Btn>}
      <Btn onClick={loadDemo}><Icon n="bolt" s={16} />Demo songs</Btn>
    </div>
  );
}

export default function Library() {
  const tracks = useStore(library, (s) => s.tracks);
  const loading = useStore(library, (s) => s.loading);
  const folder = useStore(library, (s) => s.folderName);
  const curId = useStore(player, (s) => s.trackId);
  const playing = useStore(player, (s) => s.playing);
  const [q, setQ] = useState("");
  const [scroll, setScroll] = useState(0);
  const [h, setH] = useState(600);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setH(el.clientHeight));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const list = useMemo(() => {
    const idx = tracks.map((_, i) => i);
    if (!q.trim()) return idx;
    const s = q.toLowerCase();
    return idx.filter((i) => `${tracks[i].title} ${tracks[i].artist} ${tracks[i].album}`.toLowerCase().includes(s));
  }, [tracks, q]);
  const start = Math.max(0, Math.floor(scroll / ROW) - 5);
  const end = Math.min(list.length, Math.ceil((scroll + h) / ROW) + 5);

  return (
    <div className="flex h-full flex-col">
      <div className="space-y-3 border-b border-line p-4">
        <div className="flex items-end justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">Library</h1>
            <p className="text-xs text-muted">{tracks.length ? `${tracks.length} tracks · ${folder}` : "No music loaded yet"}{loading && " · scanning…"}</p>
          </div>
        </div>
        <Pickers />
        {tracks.length > 0 && (
          <div className="flex items-center gap-2 rounded-xl border border-line bg-surface2 px-3">
            <Icon n="search" s={16} className="text-muted" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search title, artist, album" className="w-full bg-transparent py-2 text-sm outline-none" />
          </div>
        )}
      </div>
      <div ref={box} className="relative flex-1 overflow-y-auto" onScroll={(e) => setScroll(e.currentTarget.scrollTop)}>
        {!tracks.length && (
          <div className="flex h-full flex-col items-center justify-center gap-3 p-8 text-center text-sm text-muted">
            <Icon n="folder" s={44} className="text-accent" />
            <p>Pick your music folder. Subfolders are scanned, and matching <b>.lrc / .srt</b> files next to songs are attached automatically.</p>
          </div>
        )}
        <div style={{ height: list.length * ROW }} className="relative">
          {list.slice(start, end).map((ti, k) => {
            const t = tracks[ti];
            const on = t.id === curId;
            return (
              <button
                key={t.id}
                onClick={() => playTrackIndex(ti)}
                className={`absolute left-0 right-0 flex items-center gap-3 px-4 text-left transition hover:bg-surface2 ${on ? "bg-surface2" : ""}`}
                style={{ top: (start + k) * ROW, height: ROW }}
              >
                <Cover src={t.cover} size={44} />
                <div className="min-w-0 flex-1">
                  <div className={`truncate text-sm font-medium ${on ? "text-accent" : ""}`}>{t.title}</div>
                  <div className="truncate text-xs text-muted">{t.artist} · {t.album}</div>
                </div>
                {(t.sidecar || t.embeddedLyrics) && <span className="rounded border border-line px-1 text-[9px] text-muted">LRC</span>}
                {t.rgTrack != null && <span className="rounded border border-line px-1 text-[9px] text-muted">RG</span>}
                {on && playing ? <EqBars /> : <span className="w-10 text-right font-mono text-[11px] text-muted">{t.duration ? fmt(t.duration) : ""}</span>}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function EqBars() {
  return (
    <span className="flex h-4 w-10 items-end justify-end gap-0.5">
      {[0, 1, 2].map((i) => (
        <span key={i} className="w-1 rounded-sm bg-accent" style={{ height: "100%", animation: `eqb 0.${7 + i}s ease-in-out ${i * 0.15}s infinite alternate` }} />
      ))}
      <style>{`@keyframes eqb{from{transform:scaleY(.25)}to{transform:scaleY(1)}}span>span{transform-origin:bottom}`}</style>
    </span>
  );
}
