import { useState } from "react";
import { useStore, settings, player, WIDGET_IDS, type ThemeName, type WidgetId } from "../lib/store";
import { devices, requestDeviceNames } from "../lib/devices";
import { engine } from "../lib/engine";
import { Card, Toggle, Slider, Chip, Btn, Icon } from "./ui";
import { Calibrate } from "./Lyrics";

export const THEMES: { id: ThemeName; name: string; sub: string; c: string[] }[] = [
  { id: "system", name: "System", sub: "Follows device", c: ["#f4f5f8", "#0b0c10", "#8b93ff"] },
  { id: "light", name: "Light", sub: "Clean & bright", c: ["#ffffff", "#4f46e5", "#0891b2"] },
  { id: "dark", name: "Dark", sub: "OLED-friendly", c: ["#0b0c10", "#8b93ff", "#22d3ee"] },
  { id: "miku", name: "Miku", sub: "Teal 39 · ribbon pink", c: ["#0a1416", "#39c5bb", "#e12885"] },
  { id: "teto", name: "Teto", sub: "Crimson drills · baguette", c: ["#140a0c", "#e8455a", "#e9b56f"] },
  { id: "neru", name: "Neru", sub: "Golden tail · phone", c: ["#12110b", "#ffd60a", "#ff8a1f"] },
];

export const WIDGET_NAMES: Record<WidgetId, string> = {
  now: "Now playing",
  lyrics: "Lyrics strip",
  viz: "Mini spectrum",
  next: "Up next",
  quick: "Quick sound (boost / bass)",
  sleep: "Sleep timer",
  loop: "A-B loop & speed",
};

export default function Settings() {
  const s = useStore(settings, (x) => x);
  const outs = useStore(devices, (d) => d.outs);
  const named = useStore(devices, (d) => d.named);
  const sleepAt = useStore(player, (p) => p.sleepAt);
  const eot = useStore(player, (p) => p.sleepEndOfTrack);
  const [calib, setCalib] = useState(false);
  const [custom, setCustom] = useState("20");
  const set = settings.set;
  const move = (i: number, d: number) => {
    const w = [...s.widgets];
    const j = i + d;
    if (j < 0 || j >= w.length) return;
    [w[i], w[j]] = [w[j], w[i]];
    set({ widgets: w });
  };
  // keep widgets list complete if new ids added later
  const widgets = [...s.widgets, ...WIDGET_IDS.filter((id) => !s.widgets.some((w) => w.id === id)).map((id) => ({ id, on: false }))];

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto grid max-w-5xl gap-3 p-3 pb-6 md:grid-cols-2">
        <Card title="Theme" className="md:col-span-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {THEMES.map((t) => (
              <button key={t.id} onClick={() => set({ theme: t.id })} className={`overflow-hidden rounded-xl border-2 text-left transition active:scale-95 ${s.theme === t.id ? "border-accent" : "border-line"}`}>
                <div className="relative h-16" style={{ background: t.id === "system" ? `linear-gradient(135deg, ${t.c[0]} 50%, ${t.c[1]} 50%)` : t.c[0] }}>
                  <div className="absolute bottom-2 left-2 h-6 w-6 rounded-full" style={{ background: t.c[t.id === "system" ? 2 : 1] }} />
                  <div className="absolute bottom-2 left-9 h-3 w-10 rounded-full" style={{ background: t.c[2], opacity: 0.85 }} />
                  {t.id === "miku" && <span className="absolute right-2 top-1 font-mono text-lg font-black" style={{ color: t.c[1] }}>39</span>}
                  {t.id === "teto" && <span className="absolute right-2 top-1 text-lg">🥖</span>}
                  {t.id === "neru" && <span className="absolute right-2 top-1 text-lg">📱</span>}
                </div>
                <div className="bg-surface2 px-2 py-1.5">
                  <div className="text-sm font-semibold">{t.name}</div>
                  <div className="truncate text-[10px] text-muted">{t.sub}</div>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <Card title="Playback">
          <Toggle on={s.gapless} onChange={(v) => set({ gapless: v })} label="Gapless playback" hint="Next track is pre-buffered on a second deck and started on time" />
          <Slider label="Crossfade" min={0} max={12} step={0.5} value={s.crossfade} onChange={(v) => set({ crossfade: v })} fmt={(v) => (v ? `${v}s` : "off")} className="mt-1" />
          <div className="mt-3 text-sm">ReplayGain</div>
          <div className="mt-1 flex gap-1.5">
            {(["off", "track", "album"] as const).map((m) => <Chip key={m} active={s.rgMode === m} onClick={() => set({ rgMode: m })}>{m}</Chip>)}
          </div>
          <Slider label="ReplayGain pre-amp" min={-6} max={6} step={0.5} value={s.rgPreamp} onChange={(v) => set({ rgPreamp: v })} fmt={(v) => `${v > 0 ? "+" : ""}${v}dB`} className="mt-2" />
          <Toggle on={s.rgAnalyze} onChange={(v) => set({ rgAnalyze: v })} label="Analyze untagged files" hint="Measures loudness (≈EBU R128, −18 LUFS ref) and caches it" />
        </Card>

        <Card title="Sleep timer" right={<Icon n="timer" s={16} className="text-muted" />}>
          <div className="flex flex-wrap gap-1.5">
            {[10, 15, 30, 45, 60, 90].map((m) => <Chip key={m} onClick={() => player.set({ sleepAt: Date.now() + m * 60000, sleepEndOfTrack: false })}>{m} min</Chip>)}
            <Chip active={eot} onClick={() => player.set({ sleepEndOfTrack: !eot, sleepAt: null })}>End of track</Chip>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <input value={custom} onChange={(e) => setCustom(e.target.value)} inputMode="numeric" className="w-16 rounded-lg border border-line bg-surface2 px-2 py-1 text-center text-sm" />
            <Btn onClick={() => player.set({ sleepAt: Date.now() + (+custom || 1) * 60000, sleepEndOfTrack: false })}>Set minutes</Btn>
            {(sleepAt || eot) && <Btn onClick={() => player.set({ sleepAt: null, sleepEndOfTrack: false })}>Cancel</Btn>}
          </div>
          <p className="mt-2 text-xs text-muted">{sleepAt ? `Stops at ${new Date(sleepAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} with a 20s fade-out.` : eot ? "Stops when this track ends." : "Off"}</p>
        </Card>

        <Card title="Headphones" right={<Icon n="headphones" s={16} className="text-muted" />}>
          <Toggle on={s.pauseOnDisconnect} onChange={(v) => set({ pauseOnDisconnect: v })} label="Pause when unplugged" />
          <Toggle on={s.autoResume} onChange={(v) => set({ autoResume: v })} label="Auto-resume on reconnect" hint="Resumes only if it was paused by a disconnect" />
          <div className="mt-2 space-y-1">
            {outs.map((o) => (
              <div key={o.id} className="flex items-center justify-between gap-2 rounded-lg bg-surface2 px-2 py-1.5 text-xs">
                <span className="truncate">{o.label}</span>
                <div className="flex items-center gap-1">
                  {s.deviceMap[o.key] && <span className="text-accent">● {s.profiles.find((p) => p.id === s.deviceMap[o.key])?.name}</span>}
                  {"setSinkId" in AudioContext.prototype && <Chip onClick={() => engine.setOutput(o.id)}>Use</Chip>}
                </div>
              </div>
            ))}
            {!named && <Btn onClick={requestDeviceNames} className="w-full text-xs">Unlock device names (needs mic permission once)</Btn>}
            <p className="text-[11px] text-muted">Bind EQ profiles to devices in Sound → Headphone profiles.</p>
          </div>
        </Card>

        <Card title="Widgets" right={<Icon n="widget" s={16} className="text-muted" />}>
          <div className="space-y-1">
            {widgets.map((w, i) => (
              <div key={w.id} className="flex items-center gap-2 rounded-lg bg-surface2 px-2 py-1">
                <input type="checkbox" checked={w.on} onChange={(e) => set({ widgets: widgets.map((x) => (x.id === w.id ? { ...x, on: e.target.checked } : x)) })} className="h-4 w-4 accent-[var(--accent)]" />
                <span className="flex-1 text-sm">{WIDGET_NAMES[w.id]}</span>
                <button onClick={() => move(i, -1)} className="p-1 text-muted"><Icon n="up" s={14} /></button>
                <button onClick={() => move(i, 1)} className="p-1 text-muted"><Icon n="down" s={14} /></button>
              </div>
            ))}
          </div>
          <Toggle on={s.floatingMini} onChange={(v) => set({ floatingMini: v })} label="Floating mini-player" hint="Shown on every page except Home" />
          <p className="mt-1 text-[11px] text-muted">Lock-screen / notification controls are provided via Media Session.</p>
        </Card>

        <Card title="Lyrics sync">
          <div className="flex items-center justify-between">
            <span className="text-sm">Tap latency offset</span>
            <span className="font-mono text-accent">{s.tapLatency} ms</span>
          </div>
          <Slider min={0} max={400} step={5} value={s.tapLatency} onChange={(v) => set({ tapLatency: v })} />
          <Btn onClick={() => setCalib(true)} className="mt-1 w-full"><Icon n="tap" s={15} />Calibrate by tapping to a click track</Btn>
        </Card>

        <Card title="About · Android build">
          <p className="text-xs leading-relaxed text-muted">
            MX Player is built with Vite + React + Web Audio and packaged as an APK with Capacitor. Push to GitHub → the included workflow
            <code className="mx-1 rounded bg-surface2 px-1">.github/workflows/android.yml</code>builds a debug APK as a downloadable artifact.
            Settings, lyric edits and loudness analysis are stored offline on the device.
          </p>
          <Btn className="mt-2 w-full" onClick={() => { if (confirm("Reset all settings?")) { localStorage.removeItem("mx.settings.v1"); location.reload(); } }}>Reset settings</Btn>
        </Card>
      </div>
      {calib && <Calibrate onClose={() => setCalib(false)} />}
    </div>
  );
}
