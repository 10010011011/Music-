import { useEffect, useRef, useState } from "react";
import { useStore, settings, clock, player, fmt } from "../lib/store";
import { engine, type FullAnalysis } from "../lib/engine";
import { useCurrent } from "./Player";
import { Chip, Slider } from "./ui";

const MAPS: Record<string, number[][]> = {
  magma: [[0, 0, 4], [40, 11, 84], [101, 21, 110], [159, 42, 99], [212, 72, 66], [245, 125, 21], [250, 193, 39], [252, 253, 191]],
  viridis: [[68, 1, 84], [72, 40, 120], [62, 74, 137], [49, 104, 142], [38, 130, 142], [31, 158, 137], [53, 183, 121], [109, 205, 89], [180, 222, 44], [253, 231, 37]],
  gray: [[0, 0, 0], [255, 255, 255]],
  miku: [[4, 8, 10], [10, 60, 66], [19, 122, 127], [57, 197, 187], [225, 40, 133], [255, 235, 248]],
};
const lutCache = new Map<string, Uint8Array>();
export function lut(name: string) {
  let l = lutCache.get(name);
  if (l) return l;
  const st = MAPS[name] || MAPS.magma;
  l = new Uint8Array(256 * 3);
  for (let i = 0; i < 256; i++) {
    const x = (i / 255) * (st.length - 1);
    const a = Math.floor(x), b = Math.min(st.length - 1, a + 1), f = x - a;
    for (let c = 0; c < 3; c++) l[i * 3 + c] = st[a][c] + (st[b][c] - st[a][c]) * f;
  }
  lutCache.set(name, l);
  return l;
}

function themeColors() {
  const c = getComputedStyle(document.documentElement);
  return { a: c.getPropertyValue("--accent").trim(), b: c.getPropertyValue("--accent2").trim(), bg: c.getPropertyValue("--surface").trim(), line: c.getPropertyValue("--line").trim() };
}

type Draw = (g: CanvasRenderingContext2D, W: number, H: number, col: ReturnType<typeof themeColors>) => void;
export function LiveCanvas({ draw, className = "" }: { draw: Draw; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const theme = useStore(settings, (s) => s.theme);
  const playing = useStore(player, (s) => s.playing);
  const drawRef = useRef(draw);
  drawRef.current = draw;
  useEffect(() => {
    const c = ref.current!;
    const g = c.getContext("2d")!;
    const col = themeColors();
    let raf = 0, idle = 0;
    const loop = () => {
      const W = c.clientWidth * devicePixelRatio, H = c.clientHeight * devicePixelRatio;
      if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
      if (engine.ctx && !document.hidden) drawRef.current(g, W, H, col);
      idle = playing ? 0 : idle + 1;
      if (idle < 90) raf = requestAnimationFrame(loop); // let visuals settle, then stop to save battery
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [theme, playing]);
  return <canvas ref={ref} className={className} />;
}

/* ---------------- Live visualizers ---------------- */
let fbuf: Uint8Array<ArrayBuffer> | null = null;
let tbuf: Float32Array<ArrayBuffer> | null = null, lbuf: Float32Array<ArrayBuffer> | null = null, rbuf: Float32Array<ArrayBuffer> | null = null;
const peaksArr = new Float32Array(128);

export const drawSpectrum = (bars = 72): Draw => (g, W, H, col) => {
  const an = engine.analyser;
  if (!fbuf || fbuf.length !== an.frequencyBinCount) fbuf = new Uint8Array(an.frequencyBinCount);
  an.getByteFrequencyData(fbuf);
  g.clearRect(0, 0, W, H);
  const ny = engine.ctx!.sampleRate / 2;
  const bw = W / bars;
  const grad = g.createLinearGradient(0, H, 0, 0);
  grad.addColorStop(0, col.a);
  grad.addColorStop(1, col.b);
  g.fillStyle = grad;
  for (let i = 0; i < bars; i++) {
    const f0 = 30 * Math.pow(18000 / 30, i / bars), f1 = 30 * Math.pow(18000 / 30, (i + 1) / bars);
    const b0 = Math.floor((f0 / ny) * fbuf.length), b1 = Math.max(b0 + 1, Math.floor((f1 / ny) * fbuf.length));
    let m = 0;
    for (let b = b0; b < b1; b++) m = Math.max(m, fbuf[b]);
    const v = (m / 255) ** 1.6;
    const h = v * H * 0.95;
    g.fillRect(i * bw + 1, H - h, bw - 2, h);
    peaksArr[i] = Math.max(peaksArr[i] - H * 0.006, h);
    g.fillRect(i * bw + 1, H - peaksArr[i] - 3, bw - 2, 2);
  }
};

const drawScope: Draw = (g, W, H, col) => {
  const an = engine.analyser;
  if (!tbuf || tbuf.length !== an.fftSize) tbuf = new Float32Array(an.fftSize);
  an.getFloatTimeDomainData(tbuf);
  g.clearRect(0, 0, W, H);
  g.strokeStyle = col.line;
  g.beginPath(); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
  // trigger on rising zero-crossing for a stable picture
  let s = 0;
  for (let i = 1; i < tbuf.length / 2; i++) if (tbuf[i - 1] < 0 && tbuf[i] >= 0) { s = i; break; }
  const n = Math.min(1024, tbuf.length - s);
  g.strokeStyle = col.a;
  g.lineWidth = 2 * devicePixelRatio;
  g.beginPath();
  for (let i = 0; i < n; i++) (i ? g.lineTo : g.moveTo).call(g, (i / n) * W, H / 2 - tbuf[s + i] * H * 0.45);
  g.stroke();
};

const drawVector: Draw = (g, W, H, col) => {
  const n = engine.aL.fftSize;
  if (!lbuf || lbuf.length !== n) { lbuf = new Float32Array(n); rbuf = new Float32Array(n); }
  engine.aL.getFloatTimeDomainData(lbuf);
  engine.aR.getFloatTimeDomainData(rbuf!);
  g.globalAlpha = 0.25;
  g.fillStyle = col.bg;
  g.fillRect(0, 0, W, H);
  g.globalAlpha = 1;
  const cx = W / 2, cy = H / 2, r = Math.min(W, H) * 0.45;
  g.strokeStyle = col.line;
  g.beginPath(); g.moveTo(cx, cy - r); g.lineTo(cx, cy + r); g.moveTo(cx - r, cy); g.lineTo(cx + r, cy); g.stroke();
  g.fillStyle = col.a;
  let corr = 0, el = 0, er = 0;
  for (let i = 0; i < n; i += 2) {
    const L = lbuf[i], R = rbuf![i];
    corr += L * R; el += L * L; er += R * R;
    g.fillRect(cx + ((L - R) / Math.SQRT2) * r, cy - ((L + R) / Math.SQRT2) * r, 1.6 * devicePixelRatio, 1.6 * devicePixelRatio);
  }
  const c = corr / Math.sqrt(el * er + 1e-12);
  g.fillStyle = col.b;
  g.font = `${11 * devicePixelRatio}px monospace`;
  g.fillText(`correlation ${c.toFixed(2)}  (M up · S sideways)`, 8 * devicePixelRatio, H - 8 * devicePixelRatio);
};

const drawLiveSpec = (map: string): Draw => (g, W, H) => {
  const an = engine.analyser;
  if (!fbuf || fbuf.length !== an.frequencyBinCount) fbuf = new Uint8Array(an.frequencyBinCount);
  an.getByteFrequencyData(fbuf);
  const step = Math.max(1, Math.round(2 * devicePixelRatio));
  g.drawImage(g.canvas, -step, 0);
  const L = lut(map);
  const img = g.createImageData(step, H);
  const nb = fbuf.length;
  for (let y = 0; y < H; y++) {
    const fr = 1 - y / H;
    const b = Math.min(nb - 1, Math.floor(Math.pow(nb, fr)));
    const v = fbuf[b];
    for (let x = 0; x < step; x++) {
      const o = (y * step + x) * 4;
      img.data[o] = L[v * 3]; img.data[o + 1] = L[v * 3 + 1]; img.data[o + 2] = L[v * 3 + 2]; img.data[o + 3] = 255;
    }
  }
  g.putImageData(img, W - step, 0);
};

/* ---------------- Full-track analysis ---------------- */
function FullTrack({ kind }: { kind: "wave" | "spec" }) {
  const t = useCurrent();
  const s = useStore(settings, (x) => x);
  const [res, setRes] = useState<FullAnalysis | null>(null);
  const [busy, setBusy] = useState(false);
  const [floor, setFloor] = useState(-100);
  const [hover, setHover] = useState<string>("");
  const ref = useRef<HTMLCanvasElement>(null);
  const time = useStore(clock, (x) => x.t);
  const cols = 1400;
  useEffect(() => {
    if (!t) return;
    let alive = true;
    setBusy(true);
    engine.analyze(t, kind === "spec" ? s.fftSize : 1024, cols, kind === "spec").then((r) => alive && setRes(r)).catch(() => alive && setRes(null)).finally(() => alive && setBusy(false));
    return () => { alive = false; };
  }, [t, s.fftSize, kind]);
  useEffect(() => {
    const c = ref.current;
    if (!c || !res) return;
    const g = c.getContext("2d")!;
    const col = themeColors();
    if (kind === "wave") {
      const W = (c.width = c.clientWidth * devicePixelRatio), H = (c.height = c.clientHeight * devicePixelRatio);
      g.clearRect(0, 0, W, H);
      const grad = g.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, col.a); grad.addColorStop(0.5, col.b); grad.addColorStop(1, col.a);
      g.fillStyle = grad;
      for (let x = 0; x < W; x++) {
        const ci = Math.floor((x / W) * res.cols);
        const mn = res.peaks[ci * 2], mx = res.peaks[ci * 2 + 1];
        g.fillRect(x, H / 2 - mx * H * 0.48, 1, Math.max(1, (mx - mn) * H * 0.48));
      }
      return;
    }
    if (!res.spec) return;
    const H = 512;
    c.width = res.cols; c.height = H;
    const img = g.createImageData(res.cols, H);
    const L = lut(s.colormap);
    const ny = res.sr / 2;
    const lo = ((floor + 110) / 110) * 255;
    const scale = 255 / (255 - lo);
    const rowBin = new Uint32Array(H);
    for (let y = 0; y < H; y++) {
      const fr = 1 - y / (H - 1);
      const f = s.specLog ? 20 * Math.pow(ny / 20, fr) : fr * ny;
      rowBin[y] = Math.min(res.bins - 1, Math.floor((f / ny) * res.bins));
    }
    for (let x = 0; x < res.cols; x++) {
      const off = x * res.bins;
      for (let y = 0; y < H; y++) {
        let v = (res.spec[off + rowBin[y]] - lo) * scale;
        v = v < 0 ? 0 : v > 255 ? 255 : v | 0;
        const o = (y * res.cols + x) * 4;
        img.data[o] = L[v * 3]; img.data[o + 1] = L[v * 3 + 1]; img.data[o + 2] = L[v * 3 + 2]; img.data[o + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0);
  }, [res, s.colormap, s.specLog, floor, kind, s.theme]);
  if (!t) return <Empty />;
  const dur = res?.duration || 1;
  const onMove = (e: React.PointerEvent) => {
    if (!res) return;
    const r = e.currentTarget.getBoundingClientRect();
    const fx = (e.clientX - r.left) / r.width, fy = 1 - (e.clientY - r.top) / r.height;
    const ny = res.sr / 2;
    const f = s.specLog ? 20 * Math.pow(ny / 20, fy) : fy * ny;
    setHover(`${fmt(fx * dur)}${kind === "spec" ? ` · ${f >= 1000 ? (f / 1000).toFixed(2) + " kHz" : Math.round(f) + " Hz"}` : ""}`);
  };
  return (
    <div className="flex h-full flex-col gap-2">
      {kind === "spec" && (
        <div className="flex flex-wrap items-center gap-1.5">
          {Object.keys(MAPS).map((m) => <Chip key={m} active={s.colormap === m} onClick={() => settings.set({ colormap: m as any })}>{m}</Chip>)}
          <span className="mx-1 h-4 w-px bg-line" />
          <Chip active={!s.specLog} onClick={() => settings.set({ specLog: false })}>Linear Hz</Chip>
          <Chip active={s.specLog} onClick={() => settings.set({ specLog: true })}>Log Hz</Chip>
          <span className="mx-1 h-4 w-px bg-line" />
          {[1024, 2048, 4096, 8192].map((n) => <Chip key={n} active={s.fftSize === n} onClick={() => settings.set({ fftSize: n })}>FFT {n}</Chip>)}
          <div className="w-40"><Slider label="Floor" min={-110} max={-40} step={1} value={floor} onChange={setFloor} fmt={(v) => `${v}dB`} /></div>
        </div>
      )}
      <div className="relative min-h-0 flex-1 overflow-hidden rounded-xl border border-line bg-black/40" onPointerMove={onMove} onPointerLeave={() => setHover("")} onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); engine.seek(((e.clientX - r.left) / r.width) * dur); }}>
        <canvas ref={ref} className="h-full w-full cursor-crosshair" style={{ imageRendering: kind === "spec" ? "auto" : undefined }} />
        <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white/90 shadow-[0_0_8px_white]" style={{ left: `${(time / dur) * 100}%` }} />
        {busy && <div className="absolute inset-0 flex items-center justify-center bg-black/40 text-sm text-white">Decoding & running FFT…</div>}
        {hover && <div className="pointer-events-none absolute left-2 top-2 rounded bg-black/70 px-2 py-0.5 font-mono text-[11px] text-white">{hover}</div>}
        {kind === "spec" && res && <div className="pointer-events-none absolute right-2 top-2 rounded bg-black/60 px-2 py-0.5 font-mono text-[10px] text-white/80">{(res.sr / 2000).toFixed(1)}kHz ↑ · {res.bins} bins · {res.cols} frames</div>}
      </div>
      {res && (
        <p className="text-[11px] text-muted">
          Integrated ≈ {res.lufs.toFixed(1)} LUFS · peak {(20 * Math.log10(res.peak + 1e-9)).toFixed(1)} dBFS · ReplayGain ≈ {(-18 - res.lufs).toFixed(1)} dB
          {kind === "spec" && " · Tip: hidden images (Aphex Twin, creepypasta) show best in Linear Hz with a high floor."}
        </p>
      )}
    </div>
  );
}

const Empty = () => <div className="flex h-full items-center justify-center text-sm text-muted">Play a song first.</div>;

const TABS = [["spectrum", "Spectrum"], ["scope", "Oscilloscope"], ["vector", "Vectorscope"], ["live", "Live spectrogram"], ["wave", "Waveform"], ["spec", "Spectrogram (FFT)"]] as const;

export default function Visual() {
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("spec");
  const map = useStore(settings, (s) => s.colormap);
  return (
    <div className="flex h-full flex-col gap-3 p-3">
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {TABS.map(([k, l]) => <Chip key={k} active={tab === k} onClick={() => setTab(k)} className="shrink-0">{l}</Chip>)}
      </div>
      <div className="min-h-0 flex-1">
        {tab === "spectrum" && <LiveCanvas draw={drawSpectrum(96)} className="h-full w-full rounded-xl border border-line bg-surface" />}
        {tab === "scope" && <LiveCanvas draw={drawScope} className="h-full w-full rounded-xl border border-line bg-surface" />}
        {tab === "vector" && <LiveCanvas draw={drawVector} className="mx-auto aspect-square h-full max-w-full rounded-xl border border-line bg-surface" />}
        {tab === "live" && <LiveCanvas key={map} draw={drawLiveSpec(map)} className="h-full w-full rounded-xl border border-line bg-black" />}
        {tab === "wave" && <FullTrack kind="wave" />}
        {tab === "spec" && <FullTrack kind="spec" />}
      </div>
    </div>
  );
}
