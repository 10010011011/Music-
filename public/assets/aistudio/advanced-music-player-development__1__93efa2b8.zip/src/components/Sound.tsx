import { useEffect, useRef, useState } from "react";
import { useStore, settings, player, EQ_FREQS, toast } from "../lib/store";
import { engine } from "../lib/engine";
import { devices, saveProfile, applyProfile, requestDeviceNames } from "../lib/devices";
import { Card, Slider, Toggle, Chip, Btn, Icon } from "./ui";

const PRESETS: Record<string, number[]> = {
  Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "Bass boost": [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
  "V-shape": [5, 4, 2, 0, -2, -2, 0, 2, 4, 5],
  Vocal: [-2, -2, -1, 1, 3, 4, 3, 1, 0, -1],
  Treble: [0, 0, 0, 0, 0, 1, 2, 4, 5, 6],
  Loudness: [4, 3, 0, 0, -1, 0, -1, 0, 3, 4],
  Electronic: [5, 4, 1, 0, -2, 1, 0, 1, 4, 5],
  Acoustic: [3, 2, 1, 1, 2, 2, 3, 3, 2, 1],
  "Vocaloid pop": [3, 2, 0, -1, 0, 2, 4, 4, 3, 2],
  "Harman-ish": [4, 3.5, 2, 0, -0.5, 0, 1, 2.5, 0, -2],
};
const fq = (f: number) => (f >= 1000 ? `${f / 1000}k` : `${f}`);

function ResponseCurve() {
  const s = useStore(settings, (x) => x);
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    engine.ensure();
    const id = requestAnimationFrame(() => {
      const W = (c.width = c.clientWidth * devicePixelRatio), H = (c.height = c.clientHeight * devicePixelRatio);
      const g = c.getContext("2d")!;
      const n = 200;
      const freqs = new Float32Array(n);
      for (let i = 0; i < n; i++) freqs[i] = 20 * Math.pow(1000, i / (n - 1));
      const total = new Float32Array(n);
      const mag = new Float32Array(n), ph = new Float32Array(n);
      [...engine.eq, engine.bass, engine.treble].forEach((f) => {
        f.getFrequencyResponse(freqs, mag, ph);
        for (let i = 0; i < n; i++) total[i] += 20 * Math.log10(mag[i] || 1);
      });
      const css = getComputedStyle(document.documentElement);
      g.clearRect(0, 0, W, H);
      g.strokeStyle = css.getPropertyValue("--line");
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(0, H / 2);
      g.lineTo(W, H / 2);
      g.stroke();
      const y = (db: number) => H / 2 - (db / 15) * (H / 2 - 4);
      const grad = g.createLinearGradient(0, 0, W, 0);
      grad.addColorStop(0, css.getPropertyValue("--accent"));
      grad.addColorStop(1, css.getPropertyValue("--accent2"));
      g.strokeStyle = grad;
      g.lineWidth = 2.5 * devicePixelRatio;
      g.beginPath();
      for (let i = 0; i < n; i++) (i ? g.lineTo : g.moveTo).call(g, (i / (n - 1)) * W, y(total[i]));
      g.stroke();
      g.lineTo(W, H / 2);
      g.lineTo(0, H / 2);
      g.globalAlpha = 0.12;
      g.fillStyle = grad;
      g.fill();
      g.globalAlpha = 1;
    });
    return () => cancelAnimationFrame(id);
  }, [s.eq, s.bassDb, s.trebleDb, s.eqOn, s.theme]);
  return <canvas ref={ref} className="h-20 w-full" />;
}

export function LimiterMeter() {
  const red = useStore(player, (s) => s.limiting);
  const clip = useStore(player, (s) => s.clipping);
  const lim = useStore(settings, (s) => s.limiter);
  const w = Math.min(100, (-red / 12) * 100);
  return (
    <div className="flex items-center gap-2 text-[11px]">
      <span className={`h-2.5 w-2.5 rounded-full ${clip ? "bg-red-500 shadow-[0_0_8px_red]" : red < -0.5 ? "bg-amber-400" : "bg-emerald-500"}`} />
      <span className="text-muted">{clip ? "CLIPPING – enable limiter or lower boost" : lim ? "Limiter GR" : "Limiter off"}</span>
      {lim && (
        <>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-line"><div className="h-full bg-amber-400 transition-all" style={{ width: `${w}%` }} /></div>
          <span className="w-12 text-right font-mono">{red.toFixed(1)}dB</span>
        </>
      )}
    </div>
  );
}

export default function Sound() {
  const s = useStore(settings, (x) => x);
  const outs = useStore(devices, (d) => d.outs);
  const named = useStore(devices, (d) => d.named);
  const set = settings.set;
  const [pname, setPname] = useState("");
  const setBand = (i: number, v: number) => set({ eq: s.eq.map((x, k) => (k === i ? v : x)) });
  const activePreset = Object.entries(PRESETS).find(([, v]) => v.every((x, i) => x === s.eq[i]))?.[0];

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto grid max-w-5xl gap-3 p-3 pb-6 md:grid-cols-2">
        <Card title="Equalizer" right={<div className="w-32"><Toggle on={s.eqOn} onChange={(v) => set({ eqOn: v })} label={<span className="text-xs">{s.eqOn ? "On" : "Bypassed"}</span>} /></div>} className="md:col-span-2">
          <ResponseCurve />
          <div className="mt-2 flex justify-between gap-1 overflow-x-auto">
            {EQ_FREQS.map((f, i) => (
              <div key={f} className="flex flex-col items-center gap-1">
                <span className="font-mono text-[10px] tabular-nums text-muted">{s.eq[i] > 0 ? "+" : ""}{s.eq[i].toFixed(1)}</span>
                <Slider vertical min={-12} max={12} step={0.5} value={s.eq[i]} onChange={(v) => setBand(i, v)} />
                <span className="text-[10px] font-semibold">{fq(f)}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {Object.keys(PRESETS).map((p) => <Chip key={p} active={activePreset === p} onClick={() => set({ eq: [...PRESETS[p]] })}>{p}</Chip>)}
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <Slider label="Bass shelf (100Hz)" min={-12} max={15} step={0.5} value={s.bassDb} onChange={(v) => set({ bassDb: v })} fmt={(v) => `${v > 0 ? "+" : ""}${v}dB`} />
            <Slider label="Treble shelf (8kHz)" min={-12} max={12} step={0.5} value={s.trebleDb} onChange={(v) => set({ trebleDb: v })} fmt={(v) => `${v > 0 ? "+" : ""}${v}dB`} />
            <Slider label="Pre-amp" min={-15} max={6} step={0.5} value={s.preampDb} onChange={(v) => set({ preampDb: v })} fmt={(v) => `${v > 0 ? "+" : ""}${v}dB`} />
          </div>
          <Toggle on={s.autoPreamp} onChange={(v) => set({ autoPreamp: v })} label="Auto headroom" hint="Lowers pre-amp by the largest EQ boost so EQ never clips" />
        </Card>

        <Card title="Loudness boost">
          <Slider label="Amplitude boost" min={0} max={15} step={0.5} value={s.boostDb} onChange={(v) => set({ boostDb: v })} fmt={(v) => `+${v}dB (×${Math.pow(10, v / 20).toFixed(2)})`} />
          <Slider label="Volume" min={0} max={1} value={s.volume} onChange={(v) => set({ volume: v })} fmt={(v) => `${Math.round(v * 100)}%`} className="mt-2" />
          <Toggle on={s.limiter} onChange={(v) => set({ limiter: v })} label="Brick-wall limiter" hint="Catches peaks at −1.5 dBFS – boost without clipping" />
          <div className="mt-2"><LimiterMeter /></div>
        </Card>

        <Card title="Spatial / headphones">
          <div className="mb-2 flex flex-wrap gap-1.5">
            {([["normal", "Stereo"], ["mono", "Mono"], ["vocal", "Vocal focus"], ["karaoke", "Karaoke (no vocals)"]] as const).map(([k, l]) => (
              <Chip key={k} active={s.stereoMode === k} onClick={() => set({ stereoMode: k })}>{l}</Chip>
            ))}
          </div>
          <Slider label="Stereo width" min={0} max={2.5} value={s.width} onChange={(v) => set({ width: v, stereoMode: "normal" })} fmt={(v) => `${Math.round(v * 100)}%`} />
          <Slider label="Crossfeed (less fatigue)" min={0} max={1} value={s.crossfeed} onChange={(v) => set({ crossfeed: v })} fmt={(v) => `${Math.round(v * 100)}%`} className="mt-2" />
          <Slider label="Room ambience" min={0} max={1} value={s.room} onChange={(v) => set({ room: v })} fmt={(v) => `${Math.round(v * 100)}%`} className="mt-2" />
          <Toggle on={s.orbit} onChange={(v) => set({ orbit: v })} label="8D orbit (HRTF)" hint="Sound circles around your head – use headphones" />
          {s.orbit && <Slider label="Orbit speed" min={0.03} max={0.6} value={s.orbitSpeed} onChange={(v) => set({ orbitSpeed: v })} fmt={(v) => `${(1 / v).toFixed(1)}s/rev`} />}
        </Card>

        <Card title="Speed & pitch">
          <Slider label="Speed" min={0.5} max={2} step={0.01} value={s.speed} onChange={(v) => set({ speed: v })} fmt={(v) => `${v.toFixed(2)}×`} />
          <Toggle on={s.keepPitch} onChange={(v) => set({ keepPitch: v })} label="Keep pitch" hint={s.keepPitch ? "Time-stretch (tempo only)" : `Vinyl mode: pitch ${(12 * Math.log2(s.speed)).toFixed(1)} semitones`} />
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Chip onClick={() => set({ speed: 0.85, keepPitch: false })}>Slowed</Chip>
            <Chip onClick={() => set({ speed: 1, keepPitch: true })}>Normal</Chip>
            <Chip onClick={() => set({ speed: 1.25, keepPitch: false })}>Nightcore</Chip>
            <Chip onClick={() => set({ speed: Math.pow(2, 1 / 12), keepPitch: false })}>+1 semitone</Chip>
            <Chip onClick={() => set({ speed: Math.pow(2, -1 / 12), keepPitch: false })}>−1 semitone</Chip>
          </div>
        </Card>

        <Card title="Headphone profiles" right={<Icon n="headphones" s={16} className="text-muted" />}>
          <div className="flex gap-2">
            <input value={pname} onChange={(e) => setPname(e.target.value)} placeholder="Profile name (e.g. Galaxy Buds)" className="min-w-0 flex-1 rounded-xl border border-line bg-surface2 px-3 text-sm outline-none" />
            <Btn primary onClick={() => { if (!pname.trim()) return; saveProfile(pname.trim()); setPname(""); toast("Profile saved"); }}>Save</Btn>
          </div>
          <div className="mt-2 space-y-1.5">
            {s.profiles.map((p) => (
              <div key={p.id} className="flex items-center gap-2 rounded-xl bg-surface2 p-2 text-sm">
                <span className="flex-1 truncate font-medium">{p.name}</span>
                <select
                  className="max-w-[45%] rounded-lg border border-line bg-surface px-1 py-1 text-xs"
                  value={Object.entries(s.deviceMap).find(([, v]) => v === p.id)?.[0] ?? ""}
                  onChange={(e) => {
                    const dm = Object.fromEntries(Object.entries(s.deviceMap).filter(([, v]) => v !== p.id));
                    if (e.target.value) dm[e.target.value] = p.id;
                    set({ deviceMap: dm });
                  }}
                >
                  <option value="">Auto-apply on…</option>
                  {outs.map((o) => <option key={o.id} value={o.key}>{o.label}</option>)}
                </select>
                <Chip onClick={() => { applyProfile(p); toast(`Applied ${p.name}`); }}>Apply</Chip>
                <button onClick={() => set({ profiles: s.profiles.filter((x) => x.id !== p.id) })} className="text-muted"><Icon n="x" s={14} /></button>
              </div>
            ))}
            {!s.profiles.length && <p className="text-xs text-muted">Save the current EQ + spatial setup, then bind it to a headset. It's applied automatically when that headset connects.</p>}
            {!named && outs.length > 0 && <Btn onClick={requestDeviceNames} className="w-full text-xs">Unlock device names</Btn>}
          </div>
        </Card>
      </div>
    </div>
  );
}
