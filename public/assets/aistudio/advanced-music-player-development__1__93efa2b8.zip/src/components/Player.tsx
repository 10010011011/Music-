import { useMemo, useRef, useState, useEffect } from "react";
import { useStore, player, library, clock, settings, fmt } from "../lib/store";
import { engine } from "../lib/engine";
import { setShuffle } from "../lib/library";
import { Icon, Cover, Chip } from "./ui";

export function useCurrent() {
  const id = useStore(player, (s) => s.trackId);
  const tracks = useStore(library, (s) => s.tracks);
  return useMemo(() => tracks.find((t) => t.id === id), [id, tracks]);
}

export function SeekBar({ compact = false }: { compact?: boolean }) {
  const t = useStore(clock, (s) => s.t);
  const dur = useStore(player, (s) => s.duration);
  const a = useStore(player, (s) => s.abA);
  const b = useStore(player, (s) => s.abB);
  const [drag, setDrag] = useState<number | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  const ratio = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
  };
  const cur = drag != null ? drag * dur : t;
  const p = dur ? (cur / dur) * 100 : 0;
  return (
    <div className={compact ? "" : "select-none"}>
      <div
        ref={ref}
        className={`group relative cursor-pointer touch-none ${compact ? "h-1" : "h-6"} flex items-center`}
        onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); setDrag(ratio(e)); }}
        onPointerMove={(e) => drag != null && setDrag(ratio(e))}
        onPointerUp={(e) => { if (drag != null) engine.seek(ratio(e) * dur); setDrag(null); }}
      >
        <div className={`relative w-full overflow-hidden rounded-full bg-line ${compact ? "h-1" : "h-1.5"}`}>
          {a != null && dur > 0 && (
            <div className="absolute inset-y-0 bg-accent2/40" style={{ left: `${(a / dur) * 100}%`, width: `${(((b ?? cur) - a) / dur) * 100}%` }} />
          )}
          <div className="absolute inset-y-0 left-0 bg-accent" style={{ width: `${p}%` }} />
        </div>
        {!compact && <div className="absolute h-3.5 w-3.5 -translate-x-1/2 rounded-full bg-fg shadow ring-2 ring-accent transition-transform group-hover:scale-110" style={{ left: `${p}%` }} />}
        {!compact && a != null && <Marker at={(a / dur) * 100} label="A" />}
        {!compact && b != null && <Marker at={(b / dur) * 100} label="B" />}
      </div>
      {!compact && (
        <div className="mt-1 flex justify-between font-mono text-[11px] tabular-nums text-muted">
          <span>{fmt(cur)}</span>
          <span>-{fmt(dur - cur)}</span>
        </div>
      )}
    </div>
  );
}
const Marker = ({ at, label }: { at: number; label: string }) => (
  <span className="pointer-events-none absolute -top-1.5 -translate-x-1/2 rounded bg-accent2 px-1 text-[9px] font-bold text-white" style={{ left: `${at}%` }}>{label}</span>
);

export function Transport({ size = 1 }: { size?: number }) {
  const playing = useStore(player, (s) => s.playing);
  const shuffle = useStore(settings, (s) => s.shuffle);
  const repeat = useStore(settings, (s) => s.repeat);
  const cycle = () => {
    const r = repeat === "off" ? "all" : repeat === "all" ? "one" : "off";
    settings.set({ repeat: r });
    engine.setLoopFlag();
  };
  return (
    <div className="flex items-center justify-between gap-2">
      <button onClick={() => setShuffle(!shuffle)} className={`rounded-full p-2 ${shuffle ? "text-accent" : "text-muted"}`} title="Shuffle"><Icon n="shuffle" s={20 * size} /></button>
      <button onClick={() => engine.prev()} className="rounded-full p-2 active:scale-90" title="Previous"><Icon n="prev" s={28 * size} /></button>
      <button onClick={() => engine.toggle()} className="glow flex items-center justify-center rounded-full bg-accent text-onaccent transition active:scale-90" style={{ width: 64 * size, height: 64 * size }} title="Play/Pause">
        <Icon n={playing ? "pause" : "play"} s={30 * size} />
      </button>
      <button onClick={() => engine.next()} className="rounded-full p-2 active:scale-90" title="Next"><Icon n="next" s={28 * size} /></button>
      <button onClick={cycle} className={`relative rounded-full p-2 ${repeat !== "off" ? "text-accent" : "text-muted"}`} title={`Repeat: ${repeat}`}>
        <Icon n="repeat" s={20 * size} />
        {repeat === "one" && <span className="absolute right-0.5 top-0.5 text-[9px] font-bold">1</span>}
      </button>
    </div>
  );
}

export function ABLoop() {
  const a = useStore(player, (s) => s.abA);
  const b = useStore(player, (s) => s.abB);
  const press = () => {
    const t = engine.time;
    if (a == null) player.set({ abA: t });
    else if (b == null) t > a ? player.set({ abB: t }) : player.set({ abA: t });
    else player.set({ abA: null, abB: null });
  };
  return (
    <Chip active={a != null} onClick={press} title="A-B loop: tap to set A, again for B, again to clear">
      {a == null ? "A-B" : b == null ? `A ${fmt(a)} → B?` : `${fmt(a)}⇄${fmt(b)} ✕`}
    </Chip>
  );
}

export function SleepChip() {
  const at = useStore(player, (s) => s.sleepAt);
  const eot = useStore(player, (s) => s.sleepEndOfTrack);
  const [, force] = useState(0);
  useEffect(() => {
    if (!at) return;
    const i = setInterval(() => force((x) => x + 1), 1000);
    return () => clearInterval(i);
  }, [at]);
  const opts = [0, 15, 30, 60, -1];
  const cur = eot ? -1 : at ? 1 : 0;
  const cycle = () => {
    const idx = eot ? 4 : at ? opts.findIndex((m) => m > 0 && (at - Date.now()) / 60000 <= m) : 0;
    const nx = opts[(idx + 1) % opts.length];
    player.set({ sleepAt: nx > 0 ? Date.now() + nx * 60000 : null, sleepEndOfTrack: nx === -1 });
  };
  return (
    <Chip active={cur !== 0} onClick={cycle} title="Sleep timer (tap to cycle)">
      <span className="inline-flex items-center gap-1"><Icon n="timer" s={13} />{eot ? "End of track" : at ? fmt((at - Date.now()) / 1000) : "Sleep"}</span>
    </Chip>
  );
}

export function SpeedChip() {
  const speed = useStore(settings, (s) => s.speed);
  const steps = [0.5, 0.75, 0.85, 1, 1.1, 1.25, 1.5, 2];
  return (
    <Chip active={speed !== 1} onClick={() => settings.set({ speed: steps[(steps.indexOf(speed) + 1) % steps.length] ?? 1 })} title="Playback speed (tap to cycle)">
      {speed.toFixed(2)}×
    </Chip>
  );
}

export function MiniPlayer({ onOpen }: { onOpen: () => void }) {
  const t = useCurrent();
  const playing = useStore(player, (s) => s.playing);
  if (!t) return null;
  return (
    <div className="mx-2 mb-1 overflow-hidden rounded-2xl border border-line bg-surface/95 shadow-xl backdrop-blur">
      <SeekBar compact />
      <div className="flex items-center gap-3 p-2">
        <button onClick={onOpen} className="flex min-w-0 flex-1 items-center gap-3 text-left">
          <Cover src={t.cover} size={42} />
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">{t.title}</div>
            <div className="truncate text-xs text-muted">{t.artist}</div>
          </div>
        </button>
        <button onClick={() => engine.prev()} className="p-1.5"><Icon n="prev" s={20} /></button>
        <button onClick={() => engine.toggle()} className="flex h-10 w-10 items-center justify-center rounded-full bg-accent text-onaccent"><Icon n={playing ? "pause" : "play"} s={20} /></button>
        <button onClick={() => engine.next()} className="p-1.5"><Icon n="next" s={20} /></button>
      </div>
    </div>
  );
}
