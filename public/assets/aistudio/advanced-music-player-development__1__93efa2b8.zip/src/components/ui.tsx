import type { ReactNode, CSSProperties } from "react";

const P: Record<string, string> = {
  play: "M7 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L8.5 4.64A1 1 0 0 0 7 5.5z",
  pause: "M7 5h3.5v14H7zM13.5 5H17v14h-3.5z",
  next: "M6 6l8.5 6L6 18zM16 6h2.2v12H16z",
  prev: "M18 6l-8.5 6L18 18zM5.8 6H8v12H5.8z",
  shuffle: "M16 4l4 4-4 4M4 8h4.5c2 0 3 1 4 2.5l1 1.5c1 1.5 2 2.5 4 2.5H20M16 12l4 4-4 4M4 16h4.5c1.3 0 2.2-.4 2.9-1.1M14.3 9.1c.7-.7 1.6-1.1 2.9-1.1H20",
  repeat: "M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3",
  folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  music: "M9 18V5l11-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z",
  home: "M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  lyrics: "M4 6h16M4 10h10M4 14h16M4 18h8",
  sliders: "M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6",
  wave: "M2 12h2l2-6 3 12 3-16 3 18 3-12 2 4h2",
  gear: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z",
  plus: "M12 5v14M5 12h14",
  x: "M6 6l12 12M18 6L6 18",
  check: "M5 12l5 5L20 7",
  timer: "M12 8v5l3 2M9 2h6M12 22a8 8 0 1 0 0-16 8 8 0 0 0 0 16z",
  loop: "M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4",
  up: "M6 15l6-6 6 6",
  down: "M6 9l6 6 6-6",
  file: "M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9zM14 3v6h6",
  headphones: "M3 18v-6a9 9 0 0 1 18 0v6M21 19a2 2 0 0 1-2 2h-1v-7h3zM3 19a2 2 0 0 0 2 2h1v-7H3z",
  bolt: "M13 2L4 14h7l-1 8 9-12h-7z",
  download: "M12 3v12M7 10l5 5 5-5M5 21h14",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3",
  tap: "M9 11V5a2 2 0 1 1 4 0v6M13 10a2 2 0 1 1 4 0v2M17 11a2 2 0 1 1 4 0v4a7 7 0 0 1-7 7h-1a7 7 0 0 1-6-3.4L4 15.5a1.8 1.8 0 0 1 3-2L9 16",
  widget: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
};

export function Icon({ n, s = 20, className = "", fill = false }: { n: keyof typeof P | string; s?: number; className?: string; fill?: boolean }) {
  const isFill = fill || n === "play" || n === "pause" || n === "next" || n === "prev";
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" className={className} fill={isFill ? "currentColor" : "none"} stroke={isFill ? "none" : "currentColor"} strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={P[n] || P.music} />
    </svg>
  );
}

export function Card({ title, children, right, className = "" }: { title?: ReactNode; children: ReactNode; right?: ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl border border-line bg-surface/90 p-4 backdrop-blur ${className}`}>
      {(title || right) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          <h3 className="text-[13px] font-semibold uppercase tracking-wider text-muted">{title}</h3>
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function Slider({ label, value, min, max, step = 0.01, onChange, fmt, className = "", vertical = false }: { label?: ReactNode; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; fmt?: (v: number) => string; className?: string; vertical?: boolean }) {
  const p = ((value - min) / (max - min)) * 100;
  const input = (
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      onDoubleClick={() => onChange(min < 0 && max > 0 ? 0 : min === 0 && max === 2 ? 1 : value)}
      className={vertical ? "vslider" : "w-full"}
      style={{ "--p": `${p}%` } as CSSProperties}
    />
  );
  if (vertical) return input;
  return (
    <label className={`block ${className}`}>
      {label != null && (
        <div className="mb-0.5 flex justify-between text-xs">
          <span className="text-muted">{label}</span>
          <span className="font-mono tabular-nums">{fmt ? fmt(value) : value.toFixed(2)}</span>
        </div>
      )}
      {input}
    </label>
  );
}

export function Toggle({ on, onChange, label, hint }: { on: boolean; onChange: (v: boolean) => void; label: ReactNode; hint?: ReactNode }) {
  return (
    <button onClick={() => onChange(!on)} className="flex w-full items-center justify-between gap-3 py-1.5 text-left">
      <span>
        <span className="block text-sm">{label}</span>
        {hint && <span className="block text-xs text-muted">{hint}</span>}
      </span>
      <span className={`relative h-6 w-11 shrink-0 rounded-full transition ${on ? "bg-accent" : "bg-line"}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
      </span>
    </button>
  );
}

export function Chip({ active, onClick, children, className = "", title }: { active?: boolean; onClick?: () => void; children: ReactNode; className?: string; title?: string }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition active:scale-95 ${active ? "border-accent bg-accent text-onaccent" : "border-line bg-surface2 text-fg hover:border-accent/60"} ${className}`}
    >
      {children}
    </button>
  );
}

export function Btn({ onClick, children, primary, className = "", title, disabled }: { onClick?: () => void; children: ReactNode; primary?: boolean; className?: string; title?: string; disabled?: boolean }) {
  return (
    <button
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium transition active:scale-95 disabled:opacity-40 ${primary ? "bg-accent text-onaccent hover:brightness-110" : "border border-line bg-surface2 hover:border-accent/60"} ${className}`}
    >
      {children}
    </button>
  );
}

export function Cover({ src, size = 48, className = "", spin = false, playing = false }: { src?: string; size?: number; className?: string; spin?: boolean; playing?: boolean }) {
  return (
    <div
      className={`relative shrink-0 overflow-hidden bg-gradient-to-br from-accent to-accent2 ${spin ? "spin-slow rounded-full" : "rounded-xl"} ${spin && !playing ? "paused-anim" : ""} ${className}`}
      style={{ width: size, height: size }}
    >
      {src ? <img src={src} alt="" className="h-full w-full object-cover" draggable={false} /> : <div className="flex h-full w-full items-center justify-center text-onaccent/80"><Icon n="music" s={size * 0.42} /></div>}
      {spin && <div className="absolute inset-0 m-auto h-[14%] w-[14%] rounded-full border border-line bg-bg" />}
    </div>
  );
}
