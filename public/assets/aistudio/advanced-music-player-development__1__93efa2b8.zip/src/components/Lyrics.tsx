import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useStore, lyricsStore, clock, settings, player, toast, type Lyrics, type Track } from "../lib/store";
import { loadLyricsFor, saveLyrics } from "../lib/library";
import { parseLyrics, toLRC, activeIndex, bakeOffset, shiftFrom, stamp } from "../lib/lyrics";
import { engine } from "../lib/engine";
import { useCurrent, SeekBar, Transport } from "./Player";
import { Icon, Btn, Chip } from "./ui";

export function useLyrics(t?: Track) {
  const l = useStore(lyricsStore, (s) => (t ? s.map[t.id] : undefined));
  useEffect(() => { if (t) loadLyricsFor(t); }, [t]);
  return l;
}

/* ---------------- Live view (also used by widgets) ---------------- */
export function LyricsView({ lyr, size = "lg", lines: maxLines }: { lyr?: Lyrics; size?: "lg" | "sm"; lines?: number }) {
  const time = useStore(clock, (s) => s.t);
  const idx = activeIndex(lyr, time);
  const box = useRef<HTMLDivElement>(null);
  const userScroll = useRef(0);
  useEffect(() => {
    const el = box.current;
    if (!el || Date.now() - userScroll.current < 3500) return;
    const line = el.querySelector<HTMLElement>(`[data-i="${Math.max(0, idx)}"]`);
    if (line) el.scrollTo({ top: line.offsetTop - el.clientHeight / 2 + line.clientHeight / 2, behavior: "smooth" });
  }, [idx]);
  if (!lyr || !lyr.lines.length) return <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted">No lyrics yet — import an .lrc, or paste text in <b>&nbsp;Edit</b>.</div>;
  const timed = lyr.lines.some((l) => l.t != null);
  if (maxLines) {
    const s = Math.max(0, idx - 1);
    return (
      <div className="space-y-1">
        {lyr.lines.slice(s, s + maxLines).map((l, k) => (
          <p key={s + k} className={`truncate transition-all ${s + k === idx ? "text-base font-bold text-accent" : "text-sm text-muted"}`}>{l.text || "♪"}</p>
        ))}
      </div>
    );
  }
  return (
    <div
      ref={box}
      onWheel={() => (userScroll.current = Date.now())}
      onTouchMove={() => (userScroll.current = Date.now())}
      className="fade-mask relative h-full overflow-y-auto px-5 py-[40%]"
    >
      {lyr.lines.map((l, i) => (
        <p
          key={i}
          data-i={i}
          onClick={() => l.t != null && engine.seek(l.t + lyr.offset)}
          className={`origin-left cursor-pointer py-1.5 font-bold leading-snug transition-all duration-300 ${size === "lg" ? "text-2xl" : "text-lg"} ${
            !timed ? "text-fg/80" : i === idx ? "scale-[1.04] text-accent" : i < idx ? "text-muted/60" : "text-fg/45 hover:text-fg/80"
          }`}
        >
          {l.text || "♪"}
        </p>
      ))}
    </div>
  );
}

/* ---------------- Page ---------------- */
export default function LyricsPage() {
  const t = useCurrent();
  const lyr = useLyrics(t);
  const [mode, setMode] = useState<"view" | "edit" | "sync">("view");
  if (!t) return <div className="flex h-full items-center justify-center p-8 text-center text-muted">Play a song to view or edit its lyrics.</div>;
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-3">
        <div className="min-w-0">
          <h1 className="truncate text-lg font-bold">{t.title}</h1>
          <p className="truncate text-xs text-muted">{lyr ? `${lyr.lines.length} lines · ${lyr.source ?? ""}` : "no lyrics"}</p>
        </div>
        <div className="flex shrink-0 rounded-xl border border-line bg-surface2 p-0.5 text-xs font-semibold">
          {(["view", "edit", "sync"] as const).map((m) => (
            <button key={m} onClick={() => setMode(m)} className={`rounded-lg px-3 py-1.5 capitalize ${mode === m ? "bg-accent text-onaccent" : "text-muted"}`}>
              {m === "sync" ? "Tap-sync" : m}
            </button>
          ))}
        </div>
      </div>
      {mode === "view" && <ViewMode t={t} lyr={lyr} />}
      {mode === "edit" && <EditMode t={t} lyr={lyr} onSync={() => setMode("sync")} />}
      {mode === "sync" && <SyncMode t={t} lyr={lyr} onEdit={() => setMode("edit")} />}
    </div>
  );
}

function ViewMode({ t, lyr }: { t: Track; lyr?: Lyrics }) {
  const [amt, setAmt] = useState("1.7");
  const [fromCur, setFromCur] = useState(false);
  const time = useStore(clock, (s) => s.t);
  const off = lyr?.offset ?? 0;
  const nudge = (d: number) => lyr && saveLyrics(t.id, { ...lyr, offset: Math.round((off + d) * 100) / 100 });
  const shift = (sign: 1 | -1) => {
    const v = parseFloat(amt);
    if (!lyr || !isFinite(v)) return;
    const from = fromCur ? Math.max(0, activeIndex(lyr, time)) : 0;
    saveLyrics(t.id, shiftFrom(lyr, from, sign * v));
    toast(`Shifted ${fromCur ? `from line ${from + 1}` : "all lines"} by ${sign > 0 ? "+" : "−"}${v}s`);
  };
  return (
    <>
      <div className="min-h-0 flex-1"><LyricsView lyr={lyr} /></div>
      {lyr && lyr.lines.some((l) => l.t != null) && (
        <div className="space-y-2 border-t border-line p-3 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-muted">Live offset</span>
            {[-0.5, -0.1].map((d) => <Chip key={d} onClick={() => nudge(d)}>{d}s</Chip>)}
            <span className="w-16 text-center font-mono text-sm font-bold text-accent">{off >= 0 ? "+" : ""}{off.toFixed(2)}s</span>
            {[0.1, 0.5].map((d) => <Chip key={d} onClick={() => nudge(d)}>+{d}s</Chip>)}
            {off !== 0 && <Chip onClick={() => saveLyrics(t.id, bakeOffset(lyr))} title="Write offset into every timestamp">Bake</Chip>}
            {off !== 0 && <Chip onClick={() => saveLyrics(t.id, { ...lyr, offset: 0 })}>Reset</Chip>}
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-muted">Shift timestamps</span>
            <input value={amt} onChange={(e) => setAmt(e.target.value)} inputMode="decimal" className="w-16 rounded-lg border border-line bg-surface2 px-2 py-1 text-center font-mono" />
            <span className="text-muted">s</span>
            <Chip onClick={() => shift(1)}>Later +</Chip>
            <Chip onClick={() => shift(-1)}>Earlier −</Chip>
            <label className="ml-1 flex items-center gap-1 text-muted"><input type="checkbox" checked={fromCur} onChange={(e) => setFromCur(e.target.checked)} className="accent-[var(--accent)]" /> from current line</label>
          </div>
        </div>
      )}
    </>
  );
}

function download(name: string, text: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function EditMode({ t, lyr, onSync }: { t: Track; lyr?: Lyrics; onSync: () => void }) {
  const [text, setText] = useState(() => (lyr ? toLRC(lyr) : ""));
  const fileRef = useRef<HTMLInputElement>(null);
  const save = (txt = text, src = "edited") => {
    const p = parseLyrics(txt, src);
    saveLyrics(t.id, p);
    setText(toLRC(p));
    toast(`Saved ${p.lines.length} lines`);
    return p;
  };
  return (
    <div className="flex min-h-0 flex-1 flex-col gap-2 p-3">
      <div className="flex flex-wrap gap-2">
        <input ref={fileRef} type="file" accept=".lrc,.srt,.vtt,.txt,text/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) save(await f.text(), f.name); e.target.value = ""; }} />
        <Btn primary onClick={() => save()}><Icon n="check" s={15} />Save</Btn>
        <Btn onClick={() => fileRef.current?.click()}><Icon n="file" s={15} />Import .lrc/.srt/.txt</Btn>
        <Btn onClick={async () => { try { setText(await navigator.clipboard.readText()); } catch { toast("Clipboard blocked – long-press & paste instead"); } }}>Paste</Btn>
        <Btn onClick={() => setText(text.split("\n").map((l) => l.replace(/^(\s*\[\d+:\d+(?:[.:]\d+)?\])+/, "")).join("\n"))} title="Remove all timestamps">Strip times</Btn>
        <Btn onClick={() => download(`${t.artist} - ${t.title}.lrc`, toLRC(lyr ?? parseLyrics(text), { ti: t.title, ar: t.artist }))}><Icon n="download" s={15} />Export</Btn>
        <Btn onClick={() => { save(text); onSync(); }}><Icon n="tap" s={15} />Save & tap-sync</Btn>
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        spellCheck={false}
        placeholder={"Paste plain lyrics (one line per row) or LRC:\n[00:12.40]First line\n[00:15.80]Second line\n\nSRT / VTT also work."}
        className="min-h-0 flex-1 resize-none rounded-xl border border-line bg-surface2 p-3 font-mono text-[13px] leading-relaxed outline-none focus:border-accent"
      />
    </div>
  );
}

function SyncMode({ t, lyr, onEdit }: { t: Track; lyr?: Lyrics; onEdit: () => void }) {
  const latency = useStore(settings, (s) => s.tapLatency);
  const speed = useStore(settings, (s) => s.speed);
  const time = useStore(clock, (s) => s.t);
  const lines = lyr?.lines ?? [];
  const firstOpen = useMemo(() => { const i = lines.findIndex((l) => l.t == null); return i < 0 ? lines.length : i; }, [t.id]); // eslint-disable-line
  const [target, setTarget] = useState(firstOpen);
  const [calib, setCalib] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const lyrRef = useRef(lyr);
  lyrRef.current = lyr;
  const playingIdx = activeIndex(lyr, time);

  const now = () => Math.max(0, engine.time - (latency / 1000) * (speed || 1) - (lyrRef.current?.offset ?? 0));
  const setLine = useCallback((i: number, tm: number | null) => {
    const l = lyrRef.current;
    if (!l) return;
    saveLyrics(t.id, { ...l, lines: l.lines.map((x, k) => (k === i ? { ...x, t: tm == null ? null : Math.round(tm * 100) / 100 } : x)) });
  }, [t.id]);
  const tap = useCallback(() => {
    const l = lyrRef.current;
    if (!l || target >= l.lines.length) return;
    setLine(target, now());
    setTarget((x) => Math.min(l.lines.length, x + 1));
  }, [target, setLine, latency, speed]); // eslint-disable-line
  const undo = useCallback(() => {
    if (target <= 0) return;
    setLine(target - 1, null);
    setTarget(target - 1);
  }, [target, setLine]);

  useEffect(() => {
    const focus = target >= lines.length ? Math.max(0, activeIndex(lyrRef.current, engine.time)) : target;
    const el = box.current?.querySelector<HTMLElement>(`[data-i="${focus}"]`);
    const c = box.current;
    if (el && c) c.scrollTo({ top: el.offsetTop - c.clientHeight * 0.4, behavior: "smooth" });
  }, [target, lines.length]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT" || calib) return;
      if (e.code === "Space" || e.code === "Enter") { e.preventDefault(); tap(); }
      else if (e.code === "Backspace") { e.preventDefault(); undo(); }
      else if (e.code === "ArrowLeft") engine.seek(engine.time - 3);
      else if (e.code === "ArrowRight") engine.seek(engine.time + 3);
      else if (e.code === "ArrowUp") setTarget((x) => Math.max(0, x - 1));
      else if (e.code === "ArrowDown") setTarget((x) => Math.min(lines.length, x + 1));
    };
    window.addEventListener("keydown", k, true); // capture: runs before global shortcuts
    return () => window.removeEventListener("keydown", k, true);
  }, [tap, undo, lines.length, calib]);

  if (!lines.length)
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center text-sm text-muted">
        <Icon n="tap" s={40} className="text-accent" />
        Paste or type the lyrics first, then come back here and tap along while the song plays.
        <Btn primary onClick={onEdit}>Go to Edit</Btn>
      </div>
    );
  const done = lines.filter((l) => l.t != null).length;
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex flex-wrap items-center gap-1.5 border-b border-line px-3 py-2 text-xs">
        <span className="text-muted">Latency</span>
        <span className="font-mono font-bold text-accent">{latency}ms</span>
        <Chip onClick={() => setCalib(true)}>Calibrate</Chip>
        <span className="ml-2 text-muted">Speed</span>
        {[0.5, 0.75, 1].map((s) => <Chip key={s} active={speed === s} onClick={() => settings.set({ speed: s })}>{s}×</Chip>)}
        <span className="ml-auto font-mono text-muted">{done}/{lines.length}</span>
        <Chip onClick={() => { engine.seek(0); setTarget(0); }}>⟲ Restart</Chip>
        <Chip onClick={() => { if (lyr && confirm("Clear all timestamps?")) { saveLyrics(t.id, { ...lyr, lines: lyr.lines.map((l) => ({ ...l, t: null })) }); setTarget(0); } }}>Clear</Chip>
      </div>
      <div ref={box} className="relative min-h-0 flex-1 overflow-y-auto pb-[45%]">
        {lines.map((l, i) => {
          const isT = i === target;
          return (
            <div key={i} data-i={i} className={`flex items-center gap-2 border-b border-line/50 px-3 py-2 transition ${isT ? "bg-accent/15 ring-1 ring-inset ring-accent" : i === playingIdx ? "bg-surface2" : ""}`}>
              <button
                onPointerDown={() => { if (l.t == null) { setLine(i, now()); setTarget(i + 1); } else { setLine(i, null); setTarget(i); } }}
                className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 transition active:scale-90 ${l.t != null ? "border-accent bg-accent text-onaccent" : "border-line"}`}
                title={l.t != null ? "Clear time" : "Stamp now"}
              >
                {l.t != null && <Icon n="check" s={16} />}
              </button>
              <button onClick={() => setTarget(i)} className={`w-[68px] shrink-0 text-left font-mono text-xs ${l.t != null ? "text-accent" : "text-muted"}`}>{l.t != null ? stamp(l.t) : "--:--.--"}</button>
              <span onClick={() => setTarget(i)} className={`min-w-0 flex-1 cursor-pointer truncate text-sm ${isT ? "font-bold" : ""}`}>{l.text || "♪"}</span>
              {l.t != null && (
                <span className="flex shrink-0 items-center gap-0.5">
                  <button onClick={() => setLine(i, Math.max(0, l.t! - 0.1))} className="rounded px-1.5 py-0.5 font-mono text-[11px] text-muted hover:bg-surface2">−.1</button>
                  <button onClick={() => setLine(i, l.t! + 0.1)} className="rounded px-1.5 py-0.5 font-mono text-[11px] text-muted hover:bg-surface2">+.1</button>
                  <button onClick={() => { engine.seek(Math.max(0, l.t! + (lyr?.offset ?? 0) - 2)); engine.play(); }} className="rounded px-1 text-muted hover:text-accent" title="Preview from 2s before"><Icon n="play" s={13} /></button>
                </span>
              )}
            </div>
          );
        })}
      </div>
      <div className="space-y-2 border-t border-line bg-surface p-3">
        <SeekBar />
        <div className="flex items-center gap-2">
          <Btn onClick={undo} className="h-14 w-16" title="Undo (Backspace)">↶</Btn>
          <button onClick={() => engine.toggle()} className="h-14 w-16 rounded-xl border border-line bg-surface2" title="Play/Pause"><TransportIcon /></button>
          <button
            onPointerDown={(e) => { e.preventDefault(); tap(); }}
            disabled={target >= lines.length}
            className="glow h-14 flex-1 select-none rounded-xl bg-accent text-lg font-black tracking-widest text-onaccent transition active:scale-[0.97] disabled:opacity-40"
          >
            {target >= lines.length ? "ALL SYNCED ✓" : "TAP  ·  space"}
          </button>
        </div>
        <p className="text-center text-[11px] text-muted">Tap when each line starts · ←/→ seek 3s · ↑/↓ move target · stamps subtract {latency}ms reaction delay</p>
      </div>
      {calib && <Calibrate onClose={() => setCalib(false)} />}
    </div>
  );
}

function TransportIcon() {
  const p = useStore(player, (s) => s.playing);
  return <Icon n={p ? "pause" : "play"} s={22} className="mx-auto" />;
}

/* ---------------- Tap-latency calibration ---------------- */
export function Calibrate({ onClose }: { onClose: () => void }) {
  const [phase, setPhase] = useState<"idle" | "run" | "done">("idle");
  const [count, setCount] = useState(0);
  const [result, setResult] = useState<number | null>(null);
  const beats = useRef<number[]>([]);
  const taps = useRef<number[]>([]);
  const BEAT = 0.6, N = 16, COUNTIN = 4;
  const start = async () => {
    engine.pause();
    const ctx = engine.ensure();
    await ctx.resume();
    const t0 = ctx.currentTime + 0.4;
    beats.current = [];
    taps.current = [];
    for (let i = 0; i < N; i++) {
      const bt = t0 + i * BEAT;
      beats.current.push(bt);
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = i % 4 === 0 ? 1600 : 1000;
      g.gain.setValueAtTime(0.0001, bt);
      g.gain.exponentialRampToValueAtTime(0.5, bt + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0001, bt + 0.05);
      o.connect(g).connect(ctx.destination);
      o.start(bt);
      o.stop(bt + 0.06);
    }
    setPhase("run");
    setCount(0);
    setTimeout(() => {
      const d = taps.current.sort((a, b) => a - b);
      if (d.length < 4) { setResult(null); setPhase("done"); return; }
      const med = d[Math.floor(d.length / 2)];
      setResult(Math.max(0, Math.min(400, Math.round(med * 1000))));
      setPhase("done");
    }, (N * BEAT + 0.9) * 1000);
  };
  const tap = () => {
    if (phase !== "run" || !engine.ctx) return;
    const now = engine.ctx.currentTime;
    const b = beats.current.reduce((p, c) => (Math.abs(c - now) < Math.abs(p - now) ? c : p), Infinity);
    const bi = beats.current.indexOf(b);
    const d = now - b;
    if (bi >= COUNTIN && Math.abs(d) < BEAT / 2) taps.current.push(d);
    setCount((c) => c + 1);
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-sm space-y-4 rounded-2xl border border-line bg-surface p-5 text-center" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-lg font-bold">Tap-latency calibration</h2>
        <p className="text-sm text-muted">You'll hear 16 clicks. Let the first 4 pass, then tap the big pad exactly on each click. We measure your reaction + audio output delay and subtract it from every tap-sync stamp.</p>
        <button
          onPointerDown={(e) => { e.preventDefault(); phase === "run" ? tap() : phase === "idle" && start(); }}
          className="glow mx-auto flex h-36 w-36 select-none items-center justify-center rounded-full bg-accent text-xl font-black text-onaccent active:scale-95"
        >
          {phase === "idle" ? "START" : phase === "run" ? `TAP ${count}` : result != null ? `${result}ms` : "retry"}
        </button>
        {phase === "done" && (
          <div className="flex justify-center gap-2">
            <Btn onClick={() => { setPhase("idle"); setResult(null); }}>Again</Btn>
            {result != null && <Btn primary onClick={() => { settings.set({ tapLatency: result }); toast(`Tap latency set to ${result}ms`); onClose(); }}>Use {result}ms</Btn>}
          </div>
        )}
        <div className="flex items-center justify-center gap-2 text-xs text-muted">
          Manual:
          <input type="number" className="w-20 rounded border border-line bg-surface2 px-2 py-1 text-center" defaultValue={settings.get().tapLatency} onChange={(e) => settings.set({ tapLatency: Math.max(0, Math.min(600, +e.target.value || 0)) })} /> ms
        </div>
      </div>
    </div>
  );
}

export { Transport };
