import { useStore, settings, library, player, type WidgetId } from "../lib/store";
import { engine } from "../lib/engine";
import { useCurrent, SeekBar, Transport, ABLoop, SpeedChip, SleepChip } from "./Player";
import { LyricsView, useLyrics } from "./Lyrics";
import { LiveCanvas, drawSpectrum } from "./Visual";
import { LimiterMeter } from "./Sound";
import { Pickers } from "./Library";
import { Card, Cover, Slider, Chip, Icon } from "./ui";

const spec40 = drawSpectrum(40);

function NowWidget() {
  const t = useCurrent();
  const playing = useStore(player, (s) => s.playing);
  const rg = useStore(player, (s) => s.rgApplied);
  const out = useStore(player, (s) => s.outputLabel);
  const s = useStore(settings, (x) => x);
  if (!t) return null;
  return (
    <section className="relative overflow-hidden rounded-3xl border border-line bg-surface p-5 md:row-span-3">
      {t.cover && <img src={t.cover} alt="" className="pointer-events-none absolute inset-0 h-full w-full scale-125 object-cover opacity-20 blur-3xl" />}
      <div className="relative flex flex-col items-center gap-4">
        <div className={`transition-transform duration-500 ${playing ? "scale-100" : "scale-95"}`}>
          <Cover src={t.cover} size={Math.min(300, window.innerWidth - 90)} className="glow rounded-3xl" />
        </div>
        <div className="w-full text-center">
          <h2 className="truncate text-xl font-bold">{t.title}</h2>
          <p className="truncate text-sm text-muted">{t.artist} · {t.album}</p>
        </div>
        <div className="w-full"><SeekBar /></div>
        <div className="w-full max-w-sm"><Transport /></div>
        <div className="flex flex-wrap justify-center gap-1.5">
          <ABLoop />
          <SpeedChip />
          <SleepChip />
        </div>
        <div className="flex flex-wrap justify-center gap-1.5 text-[10px] text-muted">
          {s.rgMode !== "off" && <span className="rounded-full border border-line px-2 py-0.5">RG {rg > 0 ? "+" : ""}{rg.toFixed(1)}dB</span>}
          {s.gapless && <span className="rounded-full border border-line px-2 py-0.5">gapless</span>}
          {s.crossfade > 0 && <span className="rounded-full border border-line px-2 py-0.5">xfade {s.crossfade}s</span>}
          {s.boostDb > 0 && <span className="rounded-full border border-line px-2 py-0.5">boost +{s.boostDb}dB</span>}
          {s.orbit && <span className="rounded-full border border-line px-2 py-0.5">8D</span>}
          {s.stereoMode !== "normal" && <span className="rounded-full border border-line px-2 py-0.5">{s.stereoMode}</span>}
          {out && <span className="rounded-full border border-accent px-2 py-0.5 text-accent">🎧 {out}</span>}
        </div>
      </div>
    </section>
  );
}

function LyricsWidget({ go }: { go: (p: string) => void }) {
  const t = useCurrent();
  const l = useLyrics(t);
  return (
    <Card title="Lyrics" right={<button onClick={() => go("lyrics")} className="text-xs text-accent">Open →</button>}>
      {l ? <LyricsView lyr={l} lines={3} /> : <p className="text-sm text-muted">No lyrics. <button onClick={() => go("lyrics")} className="text-accent">Add some</button></p>}
    </Card>
  );
}

function NextWidget() {
  const { tracks, queue, qpos } = useStore(library, (s) => s);
  const up = queue.slice(qpos + 1, qpos + 5);
  return (
    <Card title="Up next">
      <div className="space-y-1">
        {up.map((ti, k) => (
          <button key={ti} onClick={() => engine.playAt(qpos + 1 + k)} className="flex w-full items-center gap-2 rounded-lg p-1 text-left hover:bg-surface2">
            <Cover src={tracks[ti].cover} size={32} className="rounded-lg" />
            <span className="min-w-0 flex-1 truncate text-sm">{tracks[ti].title}<span className="text-muted"> · {tracks[ti].artist}</span></span>
          </button>
        ))}
        {!up.length && <p className="text-sm text-muted">End of queue.</p>}
      </div>
    </Card>
  );
}

function QuickWidget() {
  const s = useStore(settings, (x) => x);
  return (
    <Card title="Quick sound">
      <Slider label="Boost" min={0} max={15} step={0.5} value={s.boostDb} onChange={(v) => settings.set({ boostDb: v })} fmt={(v) => `+${v}dB`} />
      <Slider label="Bass" min={-12} max={15} step={0.5} value={s.bassDb} onChange={(v) => settings.set({ bassDb: v })} fmt={(v) => `${v > 0 ? "+" : ""}${v}dB`} className="mt-1" />
      <div className="mt-2"><LimiterMeter /></div>
    </Card>
  );
}

function SleepWidget() {
  return (
    <Card title="Sleep timer">
      <div className="flex flex-wrap gap-1.5">
        <SleepChip />
        {[15, 30, 60].map((m) => <Chip key={m} onClick={() => player.set({ sleepAt: Date.now() + m * 60000, sleepEndOfTrack: false })}>{m}m</Chip>)}
      </div>
    </Card>
  );
}

export default function Home({ go }: { go: (p: string) => void }) {
  const widgets = useStore(settings, (s) => s.widgets);
  const t = useCurrent();
  const count = useStore(library, (s) => s.tracks.length);

  if (!count)
    return (
      <div className="flex h-full flex-col items-center justify-center gap-6 overflow-y-auto p-6 text-center">
        <div className="relative">
          <div className="glow flex h-28 w-28 items-center justify-center rounded-[2rem] bg-gradient-to-br from-accent to-accent2 text-onaccent"><Icon n="music" s={56} /></div>
        </div>
        <div>
          <h1 className="text-3xl font-black tracking-tight">MX Player</h1>
          <p className="mt-1 text-sm text-muted">No-nonsense local music · lyrics studio · real DSP</p>
        </div>
        <Pickers big />
        <div className="grid max-w-xl grid-cols-2 gap-2 text-left text-xs sm:grid-cols-3">
          {["Gapless + crossfade", "ReplayGain / auto-loudness", "10-band EQ + limiter", "LRC/SRT import + tap-sync", "Shift lyrics ±1.7s", "Spectrogram (hidden images)", "8D / crossfeed / karaoke", "Per-headphone profiles", "A-B loop · speed · sleep"].map((f) => (
            <div key={f} className="rounded-xl border border-line bg-surface/80 px-3 py-2">✦ {f}</div>
          ))}
        </div>
        <p className="text-xs text-muted">Tip: tap <b>Demo songs</b> to try everything right now. They come with synced lyrics and a hidden picture in the spectrogram.</p>
      </div>
    );

  const map: Record<WidgetId, React.ReactNode> = {
    now: <NowWidget key="now" />,
    lyrics: <LyricsWidget key="lyrics" go={go} />,
    viz: t ? (
      <Card key="viz" title="Spectrum" right={<button onClick={() => go("visual")} className="text-xs text-accent">Lab →</button>}>
        <LiveCanvas draw={spec40} className="h-24 w-full" />
      </Card>
    ) : null,
    next: <NextWidget key="next" />,
    quick: <QuickWidget key="quick" />,
    sleep: <SleepWidget key="sleep" />,
    loop: (
      <Card key="loop" title="Loop & speed">
        <div className="flex flex-wrap gap-1.5"><ABLoop /><SpeedChip /></div>
      </Card>
    ),
  };
  return (
    <div className="h-full overflow-y-auto">
      {!t && (
        <div className="p-4 text-center text-sm text-muted">
          {count} tracks ready. <button className="text-accent" onClick={() => engine.playAt(0)}>Start playing ▶</button>
        </div>
      )}
      <div className="mx-auto grid max-w-5xl gap-3 p-3 pb-6 md:grid-cols-2">{widgets.filter((w) => w.on).map((w) => map[w.id])}</div>
    </div>
  );
}
