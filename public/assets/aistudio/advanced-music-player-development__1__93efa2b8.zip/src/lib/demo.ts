import { ingest } from "./library";
import { library } from "./store";

// Synthesises demo songs in-browser. Each hides a picture in its spectrogram
// (like Aphex Twin's "face" or the Pokémon creepypasta trick) – open Visual → Spectrogram (linear).
interface DemoSpec {
  title: string;
  artist: string;
  hidden: string;
  root: number; // midi
  bpm: number;
  prog: number[][];
  lyrics: string[];
}

const SPECS: DemoSpec[] = [
  {
    title: "Teal Signal (demo)",
    artist: "MX Synth",
    hidden: "MIKU ♪ 39",
    root: 57,
    bpm: 128,
    prog: [[0, 4, 7], [7, 11, 14], [9, 12, 16], [5, 9, 12]],
    lyrics: ["♪ (intro) ♪", "Signal in the teal light", "Thirty-nine voices calling", "Twin tails spinning through the night", "Sing it once and keep on falling", "Check the spectrogram tonight", "There's a secret in the sound", "♪ (outro) ♪"],
  },
  {
    title: "Baguette Drill (demo)",
    artist: "MX Synth",
    hidden: "TETO 0401",
    root: 50,
    bpm: 140,
    prog: [[0, 3, 7], [8, 12, 15], [3, 7, 10], [10, 14, 17]],
    lyrics: ["♪ (intro) ♪", "Red drills turning round and round", "April fool that came to stay", "Bread in hand and feet on ground", "Gapless into the next play", "Tap the lines to sync the sound", "Shift them all by plus or minus", "♪ (outro) ♪"],
  },
];

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

function renderText(text: string, w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  g.fillStyle = "#000";
  g.fillRect(0, 0, w, h);
  g.fillStyle = "#fff";
  let fs = Math.floor(h * 0.85);
  g.font = `900 ${fs}px system-ui, sans-serif`;
  const mw = g.measureText(text).width;
  if (mw > w * 0.94) {
    fs = Math.floor((fs * w * 0.94) / mw);
    g.font = `900 ${fs}px system-ui, sans-serif`;
  }
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, w / 2, h / 2 + 1);
  const d = g.getImageData(0, 0, w, h).data;
  const px = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) px[i] = d[i * 4] / 255;
  return px;
}

function synth(spec: DemoSpec, sr = 44100) {
  const dur = 20;
  const N = sr * dur;
  const L = new Float32Array(N), R = new Float32Array(N);
  const beat = 60 / spec.bpm;
  const bar = beat * 4;
  // pad + bass + arp
  for (let i = 0; i < N; i++) {
    const t = i / sr;
    const ci = Math.floor(t / bar) % spec.prog.length;
    const ch = spec.prog[ci];
    const tb = t % bar;
    const env = Math.min(1, tb * 4) * Math.min(1, (bar - tb) * 6);
    let pad = 0;
    for (const n of ch) {
      const f = mtof(spec.root + 12 + n);
      pad += Math.sin(2 * Math.PI * f * t) * 0.5 + Math.sin(2 * Math.PI * f * 2.003 * t) * 0.12;
    }
    pad *= 0.05 * env;
    const tq = t % beat;
    const bf = mtof(spec.root - 12 + ch[0]);
    const bass = Math.tanh(Math.sin(2 * Math.PI * bf * t) * 2) * Math.exp(-tq * 5) * 0.22;
    const kick = Math.sin(2 * Math.PI * (50 + 120 * Math.exp(-tq * 30)) * tq) * Math.exp(-tq * 9) * 0.35;
    const step = Math.floor(t / (beat / 2));
    const te = t % (beat / 2);
    const an = ch[step % 3] + (step % 6 >= 3 ? 12 : 0);
    const af = mtof(spec.root + 24 + an);
    const arp = (Math.sin(2 * Math.PI * af * t) + 0.3 * Math.sin(4 * Math.PI * af * t)) * Math.exp(-te * 9) * 0.09;
    const pan = step % 2 ? 0.8 : 0.2;
    const fadeIn = Math.min(1, t / 1.5), fadeOut = Math.min(1, (dur - t) / 1.5);
    const m = (pad + bass + kick) * fadeIn * fadeOut;
    L[i] = m + arp * (1 - pan) * fadeIn * fadeOut;
    R[i] = m + arp * pan * fadeIn * fadeOut;
  }
  // hidden image: 6–16 kHz, 2s–18s
  const W = 220, H = 44;
  const px = renderText(spec.hidden, W, H);
  const t0 = 2, t1 = 18, colLen = Math.floor(((t1 - t0) / W) * sr);
  for (let r = 0; r < H; r++) {
    const f = 16000 - (r / (H - 1)) * 10000;
    const w = 2 * Math.PI * f / sr;
    for (let c = 0; c < W; c++) {
      const v = px[r * W + c];
      if (v < 0.25) continue;
      const s0 = Math.floor(t0 * sr) + c * colLen;
      const amp = 0.006 * v;
      for (let k = 0; k < colLen; k++) {
        const win = Math.sin((Math.PI * k) / colLen);
        const sv = Math.sin(w * (s0 + k)) * amp * (0.4 + 0.6 * win);
        L[s0 + k] += sv;
        R[s0 + k] += sv;
      }
    }
  }
  return { L, R, sr, dur, bar };
}

function wav(L: Float32Array, R: Float32Array, sr: number) {
  const n = L.length;
  const buf = new ArrayBuffer(44 + n * 4);
  const dv = new DataView(buf);
  const ws = (o: number, s: string) => [...s].forEach((ch, i) => dv.setUint8(o + i, ch.charCodeAt(0)));
  ws(0, "RIFF"); dv.setUint32(4, 36 + n * 4, true); ws(8, "WAVE"); ws(12, "fmt ");
  dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 2, true);
  dv.setUint32(24, sr, true); dv.setUint32(28, sr * 4, true); dv.setUint16(32, 4, true); dv.setUint16(34, 16, true);
  ws(36, "data"); dv.setUint32(40, n * 4, true);
  let o = 44;
  for (let i = 0; i < n; i++) {
    dv.setInt16(o, Math.max(-1, Math.min(1, L[i])) * 32767, true);
    dv.setInt16(o + 2, Math.max(-1, Math.min(1, R[i])) * 32767, true);
    o += 4;
  }
  return new Blob([buf], { type: "audio/wav" });
}

export async function loadDemo() {
  library.set({ loading: true });
  await new Promise((r) => setTimeout(r, 30));
  const files: { file: File; path: string }[] = [];
  const lyr: Record<string, string> = {};
  for (const [i, spec] of SPECS.entries()) {
    const { L, R, sr, bar } = synth(spec);
    const name = `${spec.artist} - ${spec.title}.wav`;
    const file = new File([wav(L, R, sr)], name, { type: "audio/wav", lastModified: 1700000000000 + i });
    files.push({ file, path: `Demo/${name}` });
    lyr[name] = spec.lyrics.map((line, k) => `[${String(Math.floor((k * bar * 1.2) / 60)).padStart(2, "0")}:${((k * bar * 1.2) % 60).toFixed(2).padStart(5, "0")}]${line}`).join("\n");
    await new Promise((r) => setTimeout(r, 0));
  }
  await ingest(files, "Demo");
  library.get().tracks.forEach((t) => ((t as any).demoLyrics = lyr[t.file.name]));
}
