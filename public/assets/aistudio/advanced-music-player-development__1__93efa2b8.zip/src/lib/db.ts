// Tiny IndexedDB key/value wrapper (lyrics edits, loudness cache, folder handle)
let dbp: Promise<IDBDatabase> | null = null;
function db() {
  if (!dbp)
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open("mx-player", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  return dbp;
}
export async function kvGet<T = unknown>(key: string): Promise<T | undefined> {
  try {
    const d = await db();
    return await new Promise((res) => {
      const q = d.transaction("kv").objectStore("kv").get(key);
      q.onsuccess = () => res(q.result as T);
      q.onerror = () => res(undefined);
    });
  } catch {
    return undefined;
  }
}
export async function kvSet(key: string, val: unknown) {
  try {
    const d = await db();
    await new Promise<void>((res) => {
      const tx = d.transaction("kv", "readwrite");
      tx.objectStore("kv").put(val, key);
      tx.oncomplete = () => res();
      tx.onerror = () => res();
    });
  } catch {}
}
export async function kvDel(key: string) {
  try {
    const d = await db();
    d.transaction("kv", "readwrite").objectStore("kv").delete(key);
  } catch {}
}
