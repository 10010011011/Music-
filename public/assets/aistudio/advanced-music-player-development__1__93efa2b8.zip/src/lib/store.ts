import { useSyncExternalStore } from "react";

export type Store<T> = {
  get: () => T;
  set: (p: Partial<T> | ((s: T) => Partial<T>)) => void;
  sub: (l: () => void) => () => void;
};

export function createStore<T extends object>(init: T, persistKey?: string): Store<T> {
  let s = init;
  if (persistKey) {
    try {
      const raw = localStorage.getItem(persistKey);
      if (raw) s = { ...init, ...JSON.parse(raw) };
    } catch {}
  }
  const ls = new Set<() => void>();
  let saveT: number | undefined;
  return {
    get: () => s,
    set: (p) => {
      const patch = typeof p === "function" ? p(s) : p;
      s = { ...s, ...patch };
      ls.forEach((l) => l());
      if (persistKey) {
        clearTimeout(saveT);
        saveT = window.setTimeout(() => localStorage.setItem(persistKey, JSON.stringify(s)), 250);
      }
    },
    sub: (l) => {
      ls.add(l);
      return () => ls.delete(l);
    },
  };
}

export function useStore<T extends object, U>(store: Store<T>, sel: (s: T) => U): U {
  return useSyncExternalStore(store.sub, () => sel(store.get()));
}

/* ---------------- Types ---------------- */
export interface Track {
  id: string;
  file: File;
  path: string;
  title: string;
  artist: string;
  album: string;
  duration?: number;
  cover?: string;
  rgTrack?: number;
  rgAlbum?: number;
  embeddedLyrics?: string;
  sidecar?: File;
  tagsDone?: boolean;
}

export interface LyricLine {
  t: number | null;
  text: string;
}
export interface Lyrics {
  lines: LyricLine[];
  offset: number; // seconds, live preview offset (display = t + offset)
  source?: string;
}

export interface SoundProfile {
  id: string;
  name: string;
  eq: number[];
  preampDb: number;
  bassDb: number;
  trebleDb: number;
  width: number;
  crossfeed: number;
}

export type ThemeName = "system" | "light" | "dark" | "miku" | "teto" | "neru";
export type StereoMode = "normal" | "mono" | "karaoke" | "vocal";

export const EQ_FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const WIDGET_IDS = ["now", "lyrics", "viz", "next", "quick", "sleep", "loop"] as const;
export type WidgetId = (typeof WIDGET_IDS)[number];

export interface Settings {
  theme: ThemeName;
  volume: number;
  boostDb: number;
  limiter: boolean;
  eqOn: boolean;
  eq: number[];
  preampDb: number;
  autoPreamp: boolean;
  bassDb: number;
  trebleDb: number;
  stereoMode: StereoMode;
  width: number;
  crossfeed: number;
  orbit: boolean;
  orbitSpeed: number;
  room: number;
  rgMode: "off" | "track" | "album";
  rgPreamp: number;
  rgAnalyze: boolean;
  gapless: boolean;
  crossfade: number;
  speed: number;
  keepPitch: boolean;
  tapLatency: number; // ms
  profiles: SoundProfile[];
  deviceMap: Record<string, string>;
  autoResume: boolean;
  pauseOnDisconnect: boolean;
  widgets: { id: WidgetId; on: boolean }[];
  floatingMini: boolean;
  colormap: "magma" | "viridis" | "gray" | "miku";
  specLog: boolean;
  fftSize: number;
  shuffle: boolean;
  repeat: "off" | "all" | "one";
}

export const defaultSettings: Settings = {
  theme: "miku",
  volume: 0.9,
  boostDb: 0,
  limiter: true,
  eqOn: true,
  eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  preampDb: 0,
  autoPreamp: true,
  bassDb: 0,
  trebleDb: 0,
  stereoMode: "normal",
  width: 1,
  crossfeed: 0,
  orbit: false,
  orbitSpeed: 0.12,
  room: 0,
  rgMode: "track",
  rgPreamp: 0,
  rgAnalyze: true,
  gapless: true,
  crossfade: 0,
  speed: 1,
  keepPitch: true,
  tapLatency: 120,
  profiles: [],
  deviceMap: {},
  autoResume: true,
  pauseOnDisconnect: true,
  widgets: WIDGET_IDS.map((id) => ({ id, on: id !== "loop" })),
  floatingMini: true,
  colormap: "magma",
  specLog: false,
  fftSize: 2048,
  shuffle: false,
  repeat: "all",
};

export const settings = createStore<Settings>(defaultSettings, "mx.settings.v1");

export interface LibState {
  tracks: Track[];
  queue: number[]; // indices into tracks
  qpos: number; // position in queue
  loading: boolean;
  folderName: string;
}
export const library = createStore<LibState>({ tracks: [], queue: [], qpos: -1, loading: false, folderName: "" });

export interface PlayerState {
  playing: boolean;
  duration: number;
  trackId: string | null;
  abA: number | null;
  abB: number | null;
  sleepAt: number | null; // epoch ms
  sleepEndOfTrack: boolean;
  limiting: number; // dB of gain reduction
  clipping: boolean;
  rgApplied: number; // dB
  outputLabel: string;
  toast: string;
}
export const player = createStore<PlayerState>({
  playing: false,
  duration: 0,
  trackId: null,
  abA: null,
  abB: null,
  sleepAt: null,
  sleepEndOfTrack: false,
  limiting: 0,
  clipping: false,
  rgApplied: 0,
  outputLabel: "",
  toast: "",
});

export const clock = createStore<{ t: number }>({ t: 0 });

export const lyricsStore = createStore<{ map: Record<string, Lyrics> }>({ map: {} });

let toastT: number | undefined;
export function toast(msg: string) {
  player.set({ toast: msg });
  clearTimeout(toastT);
  toastT = window.setTimeout(() => player.set({ toast: "" }), 2600);
}

export function currentTrack(): Track | undefined {
  const { tracks, queue, qpos } = library.get();
  return tracks[queue[qpos]];
}

export function fmt(sec: number | null | undefined) {
  if (sec == null || !isFinite(sec)) return "--:--";
  const s = Math.max(0, sec);
  const m = Math.floor(s / 60);
  return `${m}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}
