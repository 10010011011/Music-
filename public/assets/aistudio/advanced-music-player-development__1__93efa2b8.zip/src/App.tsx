import { useEffect, useState, Suspense } from "react";
import { useStore, settings, player, library } from "./lib/store";
import { engine } from "./lib/engine";
import { initDevices } from "./lib/devices";
import { MiniPlayer } from "./components/Player";
import { Icon } from "./components/ui";
import Home from "./components/Home";
import Library from "./components/Library";
import LyricsPage from "./components/Lyrics";
import Sound from "./components/Sound";
import Visual from "./components/Visual";
import Settings from "./components/Settings";

const NAV = [
  ["home", "Home", "home"],
  ["library", "Library", "music"],
  ["lyrics", "Lyrics", "lyrics"],
  ["sound", "Sound", "sliders"],
  ["visual", "Visual", "wave"],
  ["settings", "Settings", "gear"],
] as const;
type Page = (typeof NAV)[number][0];

function useTheme() {
  const theme = useStore(settings, (s) => s.theme);
  useEffect(() => {
    const mq = matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const t = theme === "system" ? (mq.matches ? "dark" : "light") : theme;
      document.documentElement.dataset.theme = t;
      let meta = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement | null;
      if (!meta) {
        meta = document.createElement("meta");
        meta.name = "theme-color";
        document.head.appendChild(meta);
      }
      meta.content = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim();
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [theme]);
}

export default function App() {
  useTheme();
  const [page, setPage] = useState<Page>("home");
  const toastMsg = useStore(player, (s) => s.toast);
  const floating = useStore(settings, (s) => s.floatingMini);
  const loading = useStore(library, (s) => s.loading);

  useEffect(() => {
    initDevices();
    const k = (e: KeyboardEvent) => {
      if (e.defaultPrevented) return;
      const tag = (e.target as HTMLElement).tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.code === "Space") { e.preventDefault(); engine.toggle(); }
      else if (e.code === "ArrowRight" && e.shiftKey) engine.next();
      else if (e.code === "ArrowLeft" && e.shiftKey) engine.prev();
      else if (e.code === "ArrowRight") engine.seek(engine.time + 5);
      else if (e.code === "ArrowLeft") engine.seek(engine.time - 5);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  const go = (p: string) => setPage(p as Page);
  const showMini = floating && page !== "home";

  return (
    <div className="flex h-full overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden w-56 shrink-0 flex-col gap-1 border-r border-line bg-surface/70 p-3 backdrop-blur md:flex">
        <div className="mb-4 flex items-center gap-2 px-2 py-1">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-accent to-accent2 text-onaccent"><Icon n="music" s={18} /></div>
          <div>
            <div className="font-black tracking-tight">MX Player</div>
            <div className="text-[10px] text-muted">local · lossless-ready</div>
          </div>
        </div>
        {NAV.map(([id, label, ic]) => (
          <button key={id} onClick={() => setPage(id)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${page === id ? "bg-accent text-onaccent" : "text-muted hover:bg-surface2 hover:text-fg"}`}>
            <Icon n={ic} s={18} /> {label}
          </button>
        ))}
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <main className="relative min-h-0 flex-1">
          <Suspense fallback={<div className="p-6 text-sm text-muted">Loading…</div>}>
            {page === "home" && <Home go={go} />}
            {page === "library" && <Library />}
            {page === "lyrics" && <LyricsPage />}
            {page === "sound" && <Sound />}
            {page === "visual" && <Visual />}
            {page === "settings" && <Settings />}
          </Suspense>
          {loading && <div className="absolute left-1/2 top-3 -translate-x-1/2 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-onaccent shadow">Scanning…</div>}
        </main>
        {showMini && <MiniPlayer onOpen={() => setPage("home")} />}
        {/* Mobile bottom nav */}
        <nav className="safe-b flex shrink-0 justify-around border-t border-line bg-surface/95 backdrop-blur md:hidden">
          {NAV.map(([id, label, ic]) => (
            <button key={id} onClick={() => setPage(id)} className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium ${page === id ? "text-accent" : "text-muted"}`}>
              <Icon n={ic} s={20} />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {toastMsg && (
        <div className="pointer-events-none fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-full border border-line bg-surface px-4 py-2 text-sm shadow-2xl md:bottom-8">{toastMsg}</div>
      )}
    </div>
  );
}
