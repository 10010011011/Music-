/// <reference types="vite/client" />

interface Window {
  showDirectoryPicker?: (opts?: { mode?: string; id?: string }) => Promise<FileSystemDirectoryHandle>;
}
interface FileSystemDirectoryHandle {
  values(): AsyncIterable<FileSystemHandle & { kind: "file" | "directory"; getFile?: () => Promise<File> }>;
  queryPermission?(o: { mode: string }): Promise<PermissionState>;
  requestPermission?(o: { mode: string }): Promise<PermissionState>;
}
interface HTMLMediaElement {
  preservesPitch: boolean;
}
interface AudioContext {
  setSinkId?: (id: string) => Promise<void>;
}
