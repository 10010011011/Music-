# MX Player 🎧

A lightweight local music player with no ads and no nonsense. Built with **React + Vite + Tailwind + Web Audio** and packaged as an **Android APK with Capacitor**. The whole app is about 100 KB gzipped.

## Features
| Area | What you get |
|---|---|
| Library | Open a folder (subfolders included), add files, reopen the last folder. Matching `.lrc/.srt/.vtt` files next to songs are attached automatically. Reads ID3v2 and FLAC tags (cover art, ReplayGain, embedded lyrics). The list is virtualized, so large folders stay fast |
| Playback | Gapless playback (a second deck pre-buffers the next track), 0–12 s crossfade, shuffle, repeat, A-B loop, speed 0.5–2× with pitch lock or vinyl mode (Nightcore / Slowed / ±semitone), sleep timer (minutes or end of track, with a 20 s fade-out) |
| Loudness | ReplayGain in track or album mode, with a pre-amp setting. Files without tags are analyzed automatically (approximates EBU R128, using −18 LUFS as the reference) and the result is cached |
| DSP | 10-band EQ with a live response curve and presets, bass/treble shelves, auto-headroom pre-amp, amplitude boost up to +15 dB behind a brick-wall limiter, with a gain-reduction meter and clip LED |
| Spatial | Stereo width (mid/side), mono, vocal focus, karaoke (vocal removal), crossfeed, 8D orbit (HRTF panner moved by audio-rate oscillators), room ambience |
| Headphones | Per-headset EQ profiles that apply automatically on connect, pause on unplug, auto-resume on reconnect, output device choice (where supported) |
| Lyrics | View mode with auto-scroll and tap-a-line-to-seek. Editing: paste or type, import LRC (multi-tag, `[offset:]`, enhanced word tags) / SRT / VTT / TXT, export `.lrc`. Live offset nudge, permanent shift of all lines (or from the current line) by any amount, e.g. `+1.7 s` |
| Tap-sync | A checkbox for each line, auto-scrolls to the line you're timing, big TAP pad, Space/Enter to tap, Backspace to undo, ±0.1 s nudges and preview. A tap-latency offset (with click-track calibration) is subtracted from every stamp and scaled by playback speed |
| Visual lab | Live spectrum, oscilloscope, stereo vectorscope with correlation, live spectrogram, full-track waveform, and a full-track FFT spectrogram (FFT size 1024–8192, linear/log frequency, magma/viridis/gray/miku colormaps, adjustable dB floor). The spectrogram is how hidden images like Aphex Twin's face show up |
| Themes | System, Light, Dark, **Miku** (#39C5BB teal and #E12885 pink), **Teto** (crimson and baguette gold), **Neru** (#FFD60A yellow and phone orange) |
| Widgets | A Home dashboard where you can turn widgets on/off and reorder them (now playing, lyrics strip, mini spectrum, up next, quick sound, sleep, loop/speed), a floating mini player, and lock-screen controls via Media Session |

The **Demo songs** button creates two songs in the app, each with synced lyrics and hidden text in the spectrogram (Visual → Spectrogram, Linear Hz).

## Build the APK on GitHub
1. Push this repo to GitHub (`main` branch).
2. **Actions → Build Android APK** runs on its own (you can also start it with *Run workflow*).
3. Download **MX-Player-APK** from the run's artifacts and install it (allow "unknown sources").
4. Push a tag like `v1.0.0` to also publish the APK as a GitHub Release.

### Local build (optional)
```bash
npm ci && npm run build
npx cap add android      # first time only
npx cap sync android
cd android && ./gradlew assembleDebug
```

### Notes for Android
- The Android WebView can't open a whole folder, so **Open folder** shows the system multi-file picker instead. Select all the songs and `.lrc` files at once.
- For long background sessions, consider adding a foreground media-service plugin, e.g. `@capgo/capacitor-media-session` or `capacitor-music-controls-plugin`.
- To make a signed release APK, add a keystore as GitHub secrets and run `assembleRelease`.
