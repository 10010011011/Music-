import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig } from "vite";

const STATIC_ASSETS = ["favicon.svg", "afterglow-cover.webp", "dm-sans-latin.woff2", "manrope-latin.woff2"];

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    {
      name: "copy-flat-static-assets",
      writeBundle(options) {
        const outDir = options.dir || "dist";
        for (const file of STATIC_ASSETS) {
          if (fs.existsSync(file)) {
            fs.copyFileSync(file, path.join(outDir, file));
          }
        }
      },
    },
  ],
});
